/**
 * Production environment settings.
 *
 * A production bundle is served from the S3 website endpoint rather than `ng serve`, so
 * there is no dev proxy any more and the gateway has to be addressed by its absolute URL.
 *
 * Every microservice sits behind the API Gateway on one EC2 instance, so this is the only
 * backend address the browser ever needs; user-service, project-service and issue-service
 * are reached through the gateway's routes and stay closed to the internet.
 *
 * This value is compiled into the bundle, so the app has to be rebuilt and re-uploaded
 * whenever the address changes. Attach an Elastic IP to the instance so that a stop/start
 * does not hand out a new one.
 */
export const environment = {
  /** True in an optimised build. */
  production: true,
  /** Absolute root of the API Gateway on EC2. */
  apiBaseUrl: 'http://54.80.100.191:8085/api',
} as const;
