package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.ChangePasswordRequest;
import com.deloitte.dto.DashboardResponse;
import com.deloitte.dto.Issue;
import com.deloitte.dto.LoginRequest;
import com.deloitte.dto.UserRequest;
import com.deloitte.entity.User;
import com.deloitte.enums.Role;

/**
 * Business contract of the User Microservice.
 *
 * <p>Programming to this interface rather than to the implementation is what lets the
 * controller stay unaware of JPA, of Feign and of how passwords are hashed.
 */
public interface UserService {

	User createUser(UserRequest request);

	User login(LoginRequest request);

	List<User> getAllUsers();

	User getUserById(long userId);

	User getUserByName(String name);

	List<User> getUsersByRole(Role role);

	User updateUser(long userId, UserRequest request);

	boolean deleteUser(long userId);

	boolean changePassword(long userId, ChangePasswordRequest request);

	boolean isEmailRegistered(String email);

	/** Inter service call: issues assigned to this user, fetched from the Issue Service. */
	List<Issue> getIssuesByUserId(long userId);

	/** Inter service call: issues assigned to this username, fetched from the Issue Service. */
	List<Issue> getIssuesByUsername(String username);

	/** Inter service aggregation across the Project Service and the Issue Service. */
	DashboardResponse getDashboard(long userId);
}
