package com.deloitte.dto;

import lombok.Data;

/** Local, read only view of a user owned by the User Service. */
@Data
public class User {

	private long userId;
	private String name;
	private String email;
	private String profile;
	private String role;
}
