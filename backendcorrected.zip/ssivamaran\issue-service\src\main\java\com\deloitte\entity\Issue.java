package com.deloitte.entity;

import java.time.LocalDate;

import com.deloitte.enums.IssueType;
import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * An issue raised against a project.
 *
 * <p>Maps to the {@code issue} table of the case study database design. The Java field names
 * are the readable {@code projectId} / {@code assigneeId}, while {@code @Column} pins the
 * physical column names to {@code project} / {@code assignee} exactly as designed.
 *
 * <p>Indexes are declared on the three foreign key style columns because every aggregation
 * endpoint in the system filters on one of them. That is the "low latency" non functional
 * requirement in practice.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "issue", indexes = {
		@Index(name = "idx_issue_project", columnList = "project"),
		@Index(name = "idx_issue_assignee", columnList = "assignee"),
		@Index(name = "idx_issue_created_by", columnList = "created_by") })
@Schema(description = "An issue raised against a project")
public class Issue {

	@Id
	@TableGenerator(name = "issue_gen", table = "id_generator",
			pkColumnName = "gen_name", valueColumnName = "gen_value",
			pkColumnValue = "issue_id", initialValue = 9001, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "issue_gen")
	@Schema(description = "Generated identifier", example = "9001")
	private long id;

	@Column(nullable = false)
	@Schema(example = "Checkout fails when the cart is empty")
	private String summary;

	@Column(length = 1000)
	@Schema(example = "Reproduced on staging: the /checkout call returns 500 when the cart has no line items.")
	private String description;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	@Schema(example = "HIGH")
	private Priority priority;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	@Schema(example = "OPEN")
	private Status status;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	@Schema(example = "BUG")
	private IssueType type;

	/** Project this issue belongs to. Validated against the Project Service on write. */
	@Column(name = "project", nullable = false)
	@Schema(example = "5001")
	private long projectId;

	/** User working on this issue. Validated against the User Service on write. */
	@Column(name = "assignee")
	@Schema(example = "1002")
	private long assigneeId;

	/** User who raised this issue, normally the Project Owner. */
	@Column(name = "created_by")
	@Schema(example = "1001")
	private long createdBy;

	@Column(name = "created_on")
	@Schema(example = "2026-02-10")
	private LocalDate createdOn;

	@Column(name = "last_updated")
	@Schema(example = "2026-02-14")
	private LocalDate lastUpdated;

	@Schema(example = "Sprint 12")
	private String sprint;

	@Column(name = "story_point")
	@Schema(example = "5")
	private Integer storyPoint;

	@Schema(description = "Free form comma separated labels", example = "payments,regression")
	private String tags;
}
