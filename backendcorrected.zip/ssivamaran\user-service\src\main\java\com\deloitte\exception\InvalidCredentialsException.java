package com.deloitte.exception;

/**
 * Thrown when a login fails. Mapped to HTTP 401.
 *
 * <p>The same message is used whether the email is unknown or the password is wrong, so the
 * API cannot be used to discover which email addresses are registered.
 */
public class InvalidCredentialsException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidCredentialsException(String message) {
		super(message);
	}
}
