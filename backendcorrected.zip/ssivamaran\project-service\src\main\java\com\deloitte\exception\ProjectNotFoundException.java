package com.deloitte.exception;

/** Thrown when a project id or project name does not exist. Mapped to HTTP 404. */
public class ProjectNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ProjectNotFoundException(String message) {
		super(message);
	}
}
