package com.deloitte.enums;

/** How urgently an issue needs attention. Persisted as text so the database stays readable. */
public enum Priority {

	LOW,
	MEDIUM,
	HIGH,
	CRITICAL
}
