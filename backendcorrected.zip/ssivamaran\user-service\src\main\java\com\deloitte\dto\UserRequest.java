package com.deloitte.dto;

import com.deloitte.enums.Role;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Payload for creating or updating a user.
 *
 * <p>A dedicated request object is used instead of the entity so a client can never supply
 * its own {@code userId} or overwrite the stored password hash by accident. The bean
 * validation annotations below are what satisfy the "validates input" step of the case study.
 */
@Data
@NoArgsConstructor
@Schema(description = "Sign up / profile update payload")
public class UserRequest {

	@NotBlank(message = "name is required")
	@Size(max = 255, message = "name must not exceed 255 characters")
	@Schema(example = "Meera Iyer")
	private String name;

	@NotBlank(message = "email is required")
	@Email(message = "email must be a valid email address")
	@Schema(example = "meera.iyer@example.com")
	private String email;

	@NotBlank(message = "password is required")
	@Size(min = 6, message = "password must be at least 6 characters")
	@Schema(example = "Secret@123")
	private String password;

	@Schema(description = "Optional profile image URL", example = "https://cdn.example.com/avatars/meera.png")
	private String profile;

	@NotNull(message = "role is required (PROJECT_OWNER or ASSIGNEE)")
	@Schema(example = "ASSIGNEE")
	private Role role;
}
