package com.deloitte.dto;

import com.deloitte.entity.User;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sign up confirmation.
 *
 * <p>The case study asks for the message "Your account is created successfully" together with
 * a hyper link to login, so the link is returned as data rather than hard coded in a UI.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Confirmation returned after a successful sign up")
public class SignUpResponse {

	@Schema(example = "Your account is created successfully")
	private String message;

	@Schema(description = "Hyper link the client should point the user to", example = "/api/users/login")
	private String loginUrl;

	@Schema(description = "The newly created user, without the password")
	private User user;
}
