package com.deloitte.dto;

import java.time.LocalDate;

import lombok.Data;

/** Local, read only view of a project owned by the Project Service. */
@Data
public class Project {

	private long id;
	private String projectName;
	private long projectOwner;
	private LocalDate startDate;
	private LocalDate endDate;
}
