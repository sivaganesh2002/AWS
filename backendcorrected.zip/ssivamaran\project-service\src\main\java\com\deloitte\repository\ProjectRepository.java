package com.deloitte.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deloitte.entity.Project;

/** Data access for the {@code project} table. */
@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {

	List<Project> findByProjectOwner(long projectOwner);

	Optional<Project> findByProjectName(String projectName);

	boolean existsByProjectName(String projectName);
}
