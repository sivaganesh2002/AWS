package com.deloitte.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.deloitte.entity.Issue;
import com.deloitte.enums.IssueType;
import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;

/** Data access for the {@code issue} table. */
@Repository
public interface IssueRepository extends JpaRepository<Issue, Long> {

	List<Issue> findByProjectId(long projectId);

	List<Issue> findByAssigneeId(long assigneeId);

	List<Issue> findByCreatedBy(long createdBy);

	List<Issue> findByStatus(Status status);

	List<Issue> findByProjectIdAndStatus(long projectId, Status status);

	long countByProjectId(long projectId);

	/**
	 * One flexible filter instead of a combinatorial explosion of derived query methods.
	 *
	 * <p>Every parameter is optional: a null simply removes that condition from the WHERE
	 * clause, so the same query backs "all HIGH bugs", "everything in project 5001" and
	 * "open issues assigned to user 1002".
	 */
	@Query("""
			SELECT i FROM Issue i
			WHERE (:projectId  IS NULL OR i.projectId  = :projectId)
			  AND (:assigneeId IS NULL OR i.assigneeId = :assigneeId)
			  AND (:createdBy  IS NULL OR i.createdBy  = :createdBy)
			  AND (:status     IS NULL OR i.status     = :status)
			  AND (:priority   IS NULL OR i.priority   = :priority)
			  AND (:type       IS NULL OR i.type       = :type)
			ORDER BY i.lastUpdated DESC
			""")
	List<Issue> search(@Param("projectId") Long projectId,
			@Param("assigneeId") Long assigneeId,
			@Param("createdBy") Long createdBy,
			@Param("status") Status status,
			@Param("priority") Priority priority,
			@Param("type") IssueType type);
}
