package com.deloitte.service;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.deloitte.client.IssueFeign;
import com.deloitte.dto.ChangePasswordRequest;
import com.deloitte.dto.DashboardResponse;
import com.deloitte.dto.Issue;
import com.deloitte.dto.LoginRequest;
import com.deloitte.dto.Project;
import com.deloitte.dto.UserRequest;
import com.deloitte.entity.User;
import com.deloitte.enums.Role;
import com.deloitte.exception.EmailAlreadyExistsException;
import com.deloitte.exception.InvalidCredentialsException;
import com.deloitte.exception.UserNotFoundException;
import com.deloitte.repository.UserRepository;

/**
 * Business logic of the User Microservice.
 *
 * <p>Every call that leaves this service is wrapped so that a downstream outage degrades the
 * response instead of failing it: if the Issue Service is unreachable the dashboard still
 * renders, just with an empty issue list. That is what keeps the system loosely coupled.
 */
@Service
public class UserServiceImpl implements UserService {

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	/** Deliberately identical for an unknown email and a wrong password, to avoid user enumeration. */
	private static final String BAD_CREDENTIALS = "Invalid email or password.";

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private IssueFeign issueFeign;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public User createUser(UserRequest request) {

		String email = request.getEmail().trim().toLowerCase();
		if (userRepository.existsByEmail(email)) {
			throw new EmailAlreadyExistsException("A user is already registered with email " + email);
		}

		User user = new User();
		user.setName(request.getName().trim());
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setProfile(request.getProfile());
		user.setRole(request.getRole());

		User saved = userRepository.save(user);
		log.info("Created user {} with role {}", saved.getUserId(), saved.getRole());
		return saved;
	}

	@Override
	public User login(LoginRequest request) {

		User user = userRepository.findByEmail(request.getEmail().trim().toLowerCase())
				.orElseThrow(() -> new InvalidCredentialsException(BAD_CREDENTIALS));

		// matches() re-hashes the supplied password with the stored salt and compares safely.
		if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
			throw new InvalidCredentialsException(BAD_CREDENTIALS);
		}

		log.info("User {} logged in", user.getUserId());
		return user;
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public User getUserById(long userId) {
		return userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("User with ID " + userId + " not found."));
	}

	@Override
	public User getUserByName(String name) {
		return userRepository.findByName(name)
				.orElseThrow(() -> new UserNotFoundException("User with username '" + name + "' not found."));
	}

	@Override
	public List<User> getUsersByRole(Role role) {
		return userRepository.findByRole(role);
	}

	@Override
	public User updateUser(long userId, UserRequest request) {

		User user = getUserById(userId);
		String email = request.getEmail().trim().toLowerCase();

		// Allow the same email only if it still belongs to this user.
		if (!user.getEmail().equals(email) && userRepository.existsByEmail(email)) {
			throw new EmailAlreadyExistsException("A user is already registered with email " + email);
		}

		user.setName(request.getName().trim());
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setProfile(request.getProfile());
		user.setRole(request.getRole());

		return userRepository.save(user);
	}

	@Override
	public boolean deleteUser(long userId) {
		User user = getUserById(userId);
		userRepository.delete(user);
		log.info("Deleted user {}", userId);
		return true;
	}

	@Override
	public boolean changePassword(long userId, ChangePasswordRequest request) {

		User user = getUserById(userId);
		if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
			throw new InvalidCredentialsException("The current password is incorrect.");
		}

		return userRepository.updateUserPassword(userId, passwordEncoder.encode(request.getNewPassword())) > 0;
	}

	@Override
	public boolean isEmailRegistered(String email) {
		return userRepository.existsByEmail(email.trim().toLowerCase());
	}

	// ---------------------------------------------------------------------
	// Inter service communication
	// ---------------------------------------------------------------------

	@Override
	public List<Issue> getIssuesByUserId(long userId) {

		getUserById(userId); // 404 early rather than returning an empty list for a user who does not exist

		try {
			ResponseEntity<List<Issue>> response = issueFeign.getIssuesByAssigneeId(userId);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("Issue Service unavailable while loading issues for user {}: {}", userId, ex.getMessage());
		}
		return Collections.emptyList();
	}

	@Override
	public List<Issue> getIssuesByUsername(String username) {
		// Resolve the username locally, then reuse the id based path.
		return getIssuesByUserId(getUserByName(username).getUserId());
	}

	@Override
	public DashboardResponse getDashboard(long userId) {

		User user = getUserById(userId);

		DashboardResponse dashboard = new DashboardResponse();
		dashboard.setUserId(user.getUserId());
		dashboard.setName(user.getName());
		dashboard.setRole(user.getRole());

		List<Project> projects = Collections.emptyList();
		List<Issue> issues;

		if (user.getRole() == Role.PROJECT_OWNER) {
			projects = fetchProjectsOwnedBy(userId);
			issues = fetchIssuesRaisedBy(userId);
		} else {
			issues = getIssuesByUserId(userId);
		}

		dashboard.setProjects(projects);
		dashboard.setTotalProjects(projects.size());
		dashboard.setIssues(issues);
		dashboard.setTotalIssues(issues.size());
		dashboard.setIssueCountByStatus(countByStatus(issues));

		return dashboard;
	}

	/**
	 * Reaches the Project Service with a load balanced {@code RestTemplate}, the style shown in
	 * the case study architecture diagram for the User to Project hop.
	 */
	private List<Project> fetchProjectsOwnedBy(long ownerId) {
		try {
			ResponseEntity<List<Project>> response = restTemplate.exchange(
					"http://project-service/api/projects/owner/" + ownerId, HttpMethod.GET, null,
					new ParameterizedTypeReference<List<Project>>() {
					});

			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("Project Service unavailable while loading projects for owner {}: {}", ownerId, ex.getMessage());
		}
		return Collections.emptyList();
	}

	/** Reaches the Issue Service with Feign for the issues this owner raised. */
	private List<Issue> fetchIssuesRaisedBy(long ownerId) {
		try {
			ResponseEntity<List<Issue>> response = issueFeign.getIssuesByOwnerId(ownerId);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("Issue Service unavailable while loading issues raised by {}: {}", ownerId, ex.getMessage());
		}
		return Collections.emptyList();
	}

	/** Small in-memory roll-up so the client does not have to count statuses itself. */
	private Map<String, Long> countByStatus(List<Issue> issues) {
		Map<String, Long> counts = new LinkedHashMap<>();
		for (Issue issue : issues) {
			String status = issue.getStatus() == null ? "UNKNOWN" : issue.getStatus();
			counts.merge(status, 1L, Long::sum);
		}
		return counts;
	}
}
