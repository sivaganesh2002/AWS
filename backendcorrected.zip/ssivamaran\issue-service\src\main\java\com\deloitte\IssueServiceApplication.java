package com.deloitte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

/**
 * Issue Microservice (Milestone 3) - the heart of the Issue Tracking System.
 *
 * <p>Owns the {@code issueservicedb} schema. It validates every issue against the Project
 * Service and the User Service, serves the by-project, by-owner and by-assignee lookups that
 * the other services aggregate, and publishes a domain event on every status change so that
 * notification or real time update modules can be plugged in later without touching this code.
 */
@SpringBootApplication
@EnableFeignClients
public class IssueServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssueServiceApplication.class, args);
	}

	@Bean
	OpenAPI issueMicroserviceOpenAPI() {
		return new OpenAPI()
				.addServersItem(new Server().url("http://localhost:8085").description("API Gateway"))
				.info(new Info().title("Issue Service")
						.description("Issue Microservice - issue lifecycle, assignment and status tracking")
						.version("1.0")
						.contact(new Contact().name("Issue Tracking System")));
	}

	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
