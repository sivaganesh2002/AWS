package com.deloitte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Cloud API Gateway - the single entry point for every REST client.
 *
 * <p>Responsibilities:
 * <ul>
 *   <li>Routes {@code /api/users/**}, {@code /api/projects/**} and {@code /api/issues/**}
 *       to the matching microservice.</li>
 *   <li>Resolves targets through Eureka using {@code lb://SERVICE-NAME}, which gives
 *       client side load balancing for free when a service is scaled to many instances.</li>
 *   <li>Exposes one aggregated Swagger UI at
 *       <a href="http://localhost:8085/swagger-ui.html">http://localhost:8085/swagger-ui.html</a>
 *       from which every microservice's API documentation can be browsed.</li>
 * </ul>
 *
 * <p>All routing is declarative and lives in {@code application.properties}, so a new
 * microservice can be plugged in without touching a single line of Java.
 */
@SpringBootApplication
public class ApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}

}
