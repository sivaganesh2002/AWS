package com.deloitte.exception;

/**
 * Thrown when an issue payload is structurally valid but semantically wrong, for example a
 * project id that does not exist or an assignee who is not a registered user.
 * Mapped to HTTP 400.
 */
public class InvalidIssueException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidIssueException(String message) {
		super(message);
	}
}
