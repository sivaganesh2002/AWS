package com.deloitte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

/**
 * User Microservice (Milestone 1)by siv 9:41.
 *
 * <p>Owns the {@code userservicedb} schema and is the only service allowed to read or write
 * user rows. It exposes sign up, login, profile management and two inter service endpoints
 * that aggregate issues belonging to a user.
 *
 * <p>Both inter service styles required by the case study are demonstrated here:
 * <ul>
 *   <li>{@code RestTemplate} (load balanced through Eureka) is used to reach the Project Service.</li>
 *   <li>{@code Feign Client} is used to reach the Issue Service.</li>
 * </ul>
 */
@SpringBootApplication
@EnableFeignClients
public class UserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiceApplication.class, args);
	}

	/** Describes this service inside the aggregated Swagger UI served by the API Gateway. */
	@Bean
	OpenAPI userMicroserviceOpenAPI() {
		return new OpenAPI()
				.addServersItem(new Server().url("http://localhost:8085").description("API Gateway"))
				.info(new Info().title("User Service")
						.description("User Microservice - sign up, login, roles and per user issue lookups")
						.version("1.0")
						.contact(new Contact().name("Issue Tracking System")));
	}

	/**
	 * {@code @LoadBalanced} lets the template resolve logical names such as
	 * {@code http://project-service/...} through Eureka instead of a fixed host and port.
	 */
	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	/**
	 * Passwords are never stored in clear text. BCrypt salts every hash automatically, so two
	 * users with the same password still end up with different values in the database.
	 */
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
