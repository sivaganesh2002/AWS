package com.deloitte.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.Project;

/**
 * Declarative HTTP client for the Project Service.
 *
 * <p>Only the plain project lookup is declared, never the Project Service's own
 * {@code /issues} endpoints. That one restriction is what prevents an infinite call loop
 * between the two services.
 */
@FeignClient(name = "project-service", path = "/api/projects")
public interface ProjectFeign {

	@GetMapping("/{projectId}")
	ResponseEntity<Project> getProjectById(@PathVariable long projectId);
}
