package com.deloitte.service;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deloitte.client.IssueFeign;
import com.deloitte.client.UserFeign;
import com.deloitte.dto.Issue;
import com.deloitte.dto.ProjectRequest;
import com.deloitte.dto.ProjectSummary;
import com.deloitte.dto.User;
import com.deloitte.entity.Project;
import com.deloitte.exception.InvalidProjectException;
import com.deloitte.exception.ProjectNotFoundException;
import com.deloitte.repository.ProjectRepository;

/**
 * Business logic of the Project Microservice.
 *
 * <p>Owner validation is best effort by design. If the User Service confirms the owner does
 * not exist the request is rejected, but if the User Service is simply unreachable the project
 * is still created and a warning is logged. A registry outage must not stop the business.
 */
@Service
public class ProjectServiceImpl implements ProjectService {

	private static final Logger log = LoggerFactory.getLogger(ProjectServiceImpl.class);

	private static final String PROJECT_OWNER_ROLE = "PROJECT_OWNER";

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private UserFeign userFeign;

	@Autowired
	private IssueFeign issueFeign;

	@Override
	public Project createProject(ProjectRequest request) {

		validateDates(request);
		validateOwner(request.getProjectOwner());

		Project project = new Project();
		project.setProjectName(request.getProjectName().trim());
		project.setProjectOwner(request.getProjectOwner());
		project.setStartDate(request.getStartDate());
		project.setEndDate(request.getEndDate());

		Project saved = projectRepository.save(project);
		log.info("Created project {} owned by user {}", saved.getId(), saved.getProjectOwner());
		return saved;
	}

	@Override
	public List<Project> getAllProjects() {
		return projectRepository.findAll();
	}

	@Override
	public Project getProjectById(long projectId) {
		return projectRepository.findById(projectId)
				.orElseThrow(() -> new ProjectNotFoundException("Project with ID " + projectId + " not found."));
	}

	@Override
	public Project getProjectByName(String projectName) {
		return projectRepository.findByProjectName(projectName)
				.orElseThrow(() -> new ProjectNotFoundException("Project '" + projectName + "' not found."));
	}

	@Override
	public List<Project> getProjectsByOwnerId(long ownerId) {
		return projectRepository.findByProjectOwner(ownerId);
	}

	@Override
	public Project updateProject(long projectId, ProjectRequest request) {

		Project project = getProjectById(projectId);

		validateDates(request);
		validateOwner(request.getProjectOwner());

		project.setProjectName(request.getProjectName().trim());
		project.setProjectOwner(request.getProjectOwner());
		project.setStartDate(request.getStartDate());
		project.setEndDate(request.getEndDate());

		return projectRepository.save(project);
	}

	@Override
	public boolean deleteProject(long projectId) {
		Project project = getProjectById(projectId);
		projectRepository.delete(project);
		log.info("Deleted project {}", projectId);
		return true;
	}

	// ---------------------------------------------------------------------
	// Inter service communication
	// ---------------------------------------------------------------------

	@Override
	public List<Issue> getIssuesByProjectId(long projectId) {

		getProjectById(projectId); // 404 early for a project that does not exist

		try {
			ResponseEntity<List<Issue>> response = issueFeign.getIssuesByProjectId(projectId);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("Issue Service unavailable while loading issues for project {}: {}", projectId, ex.getMessage());
		}
		return Collections.emptyList();
	}

	@Override
	public List<Issue> getIssuesByProjectName(String projectName) {
		// The name is resolved from this service's own database, then the id based path is reused.
		return getIssuesByProjectId(getProjectByName(projectName).getId());
	}

	@Override
	public ProjectSummary getProjectSummary(long projectId) {

		Project project = getProjectById(projectId);
		List<Issue> issues = getIssuesByProjectId(projectId);

		ProjectSummary summary = new ProjectSummary();
		summary.setProject(project);
		summary.setOwner(fetchUser(project.getProjectOwner()));
		summary.setIssues(issues);
		summary.setTotalIssues(issues.size());
		summary.setIssueCountByStatus(countByStatus(issues));

		return summary;
	}

	// ---------------------------------------------------------------------
	// Helpers
	// ---------------------------------------------------------------------

	/** An end date before the start date is nonsense no matter what the client claims. */
	private void validateDates(ProjectRequest request) {
		if (request.getEndDate().isBefore(request.getStartDate())) {
			throw new InvalidProjectException("endDate (" + request.getEndDate() + ") cannot be before startDate ("
					+ request.getStartDate() + ").");
		}
	}

	/**
	 * Confirms with the User Service that the owner exists and actually holds the
	 * PROJECT_OWNER role. A transport failure is tolerated; a definitive "no" is not.
	 */
	private void validateOwner(long ownerId) {

		User owner;
		try {
			ResponseEntity<User> response = userFeign.getUserById(ownerId);
			owner = response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
		} catch (Exception ex) {
			log.warn("User Service unavailable while validating owner {}. Proceeding without validation: {}", ownerId,
					ex.getMessage());
			return;
		}

		if (owner == null) {
			throw new InvalidProjectException("No user exists with ID " + ownerId + ".");
		}
		if (!PROJECT_OWNER_ROLE.equals(owner.getRole())) {
			throw new InvalidProjectException(
					"User " + ownerId + " has role " + owner.getRole() + " and cannot own a project.");
		}
	}

	private User fetchUser(long userId) {
		try {
			ResponseEntity<User> response = userFeign.getUserById(userId);
			if (response.getStatusCode().is2xxSuccessful()) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("User Service unavailable while loading user {}: {}", userId, ex.getMessage());
		}
		return null;
	}

	private Map<String, Long> countByStatus(List<Issue> issues) {
		Map<String, Long> counts = new LinkedHashMap<>();
		for (Issue issue : issues) {
			String status = issue.getStatus() == null ? "UNKNOWN" : issue.getStatus();
			counts.merge(status, 1L, Long::sum);
		}
		return counts;
	}
}
