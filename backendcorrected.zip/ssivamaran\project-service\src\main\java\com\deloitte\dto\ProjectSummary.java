package com.deloitte.dto;

import java.util.List;
import java.util.Map;

import com.deloitte.entity.Project;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * A project together with everything the Project Owner dashboard needs about it.
 *
 * <p>Built by calling the User Service for the owner and the Issue Service for the issues,
 * so the client gets one response instead of making three calls itself.
 */
@Data
@Schema(description = "Project detail enriched with its owner and its issues")
public class ProjectSummary {

	private Project project;

	@Schema(description = "Resolved from the User Service. Null when that service is unreachable.")
	private User owner;

	private List<Issue> issues;

	private int totalIssues;

	@Schema(description = "Issue counts per status", example = "{\"OPEN\":4,\"CLOSED\":2}")
	private Map<String, Long> issueCountByStatus;
}
