package com.deloitte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

/**
 * Project Microservice (Milestone 2).
 *
 * <p>Owns the {@code projectservicedb} schema. Beyond plain CRUD it validates the project
 * owner against the User Service and aggregates a project's issues from the Issue Service,
 * which are the two inter service endpoints required by section 7.2.
 */
@SpringBootApplication
@EnableFeignClients
public class ProjectServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectServiceApplication.class, args);
	}

	@Bean
	OpenAPI projectMicroserviceOpenAPI() {
		return new OpenAPI()
				.addServersItem(new Server().url("http://localhost:8085").description("API Gateway"))
				.info(new Info().title("Project Service")
						.description("Project Microservice - project CRUD plus issue aggregation per project")
						.version("1.0")
						.contact(new Contact().name("Issue Tracking System")));
	}

	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
