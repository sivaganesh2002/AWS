package com.deloitte.dto;

import com.deloitte.enums.IssueType;
import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Payload for creating an issue and for the full update (PUT).
 *
 * <p>{@code priority}, {@code status} and {@code type} are optional on creation: the service
 * applies sensible defaults (MEDIUM / OPEN / TASK) rather than rejecting the request, which
 * keeps the common "quick raise a bug" flow to three fields.
 */
@Data
@NoArgsConstructor
@Schema(description = "Issue create / update payload")
public class IssueRequest {

	@NotBlank(message = "summary is required")
	@Size(max = 255, message = "summary must not exceed 255 characters")
	@Schema(example = "Checkout fails when the cart is empty")
	private String summary;

	@Size(max = 1000, message = "description must not exceed 1000 characters")
	@Schema(example = "Reproduced on staging: the /checkout call returns 500 when the cart has no line items.")
	private String description;

	@NotNull(message = "projectId is required")
	@Positive(message = "projectId must be a valid project id")
	@Schema(example = "5001")
	private Long projectId;

	@Schema(description = "User id of the assignee. Omit to leave the issue unassigned.", example = "1002")
	private Long assigneeId;

	@Schema(description = "User id of the reporter", example = "1001")
	private Long createdBy;

	@Schema(description = "Defaults to MEDIUM", example = "HIGH")
	private Priority priority;

	@Schema(description = "Defaults to OPEN", example = "OPEN")
	private Status status;

	@Schema(description = "Defaults to TASK", example = "BUG")
	private IssueType type;

	@Schema(example = "Sprint 12")
	private String sprint;

	@PositiveOrZero(message = "storyPoint cannot be negative")
	@Schema(example = "5")
	private Integer storyPoint;

	@Schema(example = "payments,regression")
	private String tags;
}
