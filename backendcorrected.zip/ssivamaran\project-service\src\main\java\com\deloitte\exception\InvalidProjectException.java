package com.deloitte.exception;

/**
 * Thrown when a project payload is structurally valid but semantically wrong, for example an
 * end date before the start date or an owner who is not a registered Project Owner.
 * Mapped to HTTP 400.
 */
public class InvalidProjectException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidProjectException(String message) {
		super(message);
	}
}
