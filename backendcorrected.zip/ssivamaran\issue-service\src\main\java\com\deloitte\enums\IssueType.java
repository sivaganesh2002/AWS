package com.deloitte.enums;

/** The kind of work an issue represents. */
public enum IssueType {

	BUG,
	TASK,
	STORY,
	EPIC
}
