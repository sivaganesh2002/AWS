package com.deloitte.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Payload for creating or updating a project. */
@Data
@NoArgsConstructor
@Schema(description = "Project create / update payload")
public class ProjectRequest {

	@NotBlank(message = "projectName is required")
	@Size(max = 255, message = "projectName must not exceed 255 characters")
	@Schema(example = "Payments Platform Revamp")
	private String projectName;

	@NotNull(message = "projectOwner is required")
	@Positive(message = "projectOwner must be a valid user id")
	@Schema(description = "User id of the Project Owner", example = "1001")
	private Long projectOwner;

	@NotNull(message = "startDate is required")
	@Schema(example = "2026-01-05")
	private LocalDate startDate;

	@NotNull(message = "endDate is required")
	@Schema(example = "2026-06-30")
	private LocalDate endDate;
}
