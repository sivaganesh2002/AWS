package com.deloitte.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.deloitte.entity.User;
import com.deloitte.enums.Role;

import jakarta.transaction.Transactional;

/**
 * Data access for the {@code user} table.
 *
 * <p>Spring Data derives the SQL from the method names, so no implementation class is needed.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByEmail(String email);

	/** The case study treats the user's name as the username. */
	Optional<User> findByName(String name);

	List<User> findByRole(Role role);

	boolean existsByEmail(String email);

	@Query("UPDATE User u SET u.password = :password WHERE u.userId = :userId")
	@Transactional
	@Modifying
	int updateUserPassword(long userId, String password);
}
