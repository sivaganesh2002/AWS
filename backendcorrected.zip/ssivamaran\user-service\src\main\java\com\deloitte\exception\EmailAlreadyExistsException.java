package com.deloitte.exception;

/** Thrown when a sign up uses an email that is already registered. Mapped to HTTP 409. */
public class EmailAlreadyExistsException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EmailAlreadyExistsException(String message) {
		super(message);
	}
}
