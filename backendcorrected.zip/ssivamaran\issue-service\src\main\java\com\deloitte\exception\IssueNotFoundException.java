package com.deloitte.exception;

/** Thrown when an issue id does not exist. Mapped to HTTP 404. */
public class IssueNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public IssueNotFoundException(String message) {
		super(message);
	}
}
