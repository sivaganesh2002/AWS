package com.deloitte.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.User;

/** Declarative HTTP client for the User Service, used to validate and resolve project owners. */
@FeignClient(name = "user-service", path = "/api/users")
public interface UserFeign {

	@GetMapping("/{userId}")
	ResponseEntity<User> getUserById(@PathVariable long userId);
}
