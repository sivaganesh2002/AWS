package com.deloitte.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Credentials submitted by the common login screen shared by both roles. */
@Data
@NoArgsConstructor
@Schema(description = "Login credentials")
public class LoginRequest {

	@NotBlank(message = "email is required")
	@Email(message = "email must be a valid email address")
	@Schema(example = "meera.iyer@example.com")
	private String email;

	@NotBlank(message = "password is required")
	@Schema(example = "Secret@123")
	private String password;
}
