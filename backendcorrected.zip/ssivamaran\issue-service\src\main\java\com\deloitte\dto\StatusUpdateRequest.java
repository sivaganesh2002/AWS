package com.deloitte.dto;

import com.deloitte.enums.Status;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Assignee module's core action: move an issue to a new status.
 *
 * <p>Kept as its own tiny payload so an assignee can update a status without being able to
 * accidentally overwrite the summary, the priority or the assignment.
 */
@Data
@NoArgsConstructor
@Schema(description = "Status change payload")
public class StatusUpdateRequest {

	@NotNull(message = "status is required")
	@Schema(example = "IN_PROGRESS")
	private Status status;

	@Schema(description = "User id performing the change, recorded in the published domain event",
			example = "1002")
	private Long updatedBy;
}
