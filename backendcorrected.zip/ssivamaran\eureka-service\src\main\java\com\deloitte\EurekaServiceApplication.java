package com.deloitte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Eureka Service Registry.
 *
 * <p>Every microservice of the Issue Tracking System (user, project, issue)
 * and the API Gateway register themselves here on start-up. Services then resolve one
 * another by logical application name (for example {@code lb://ISSUE-SERVICE}) instead
 * of a hard coded host and port, which is what makes the system horizontally scalable.
 *
 * <p>Dashboard: <a href="http://localhost:8761">http://localhost:8761</a>
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServiceApplication.class, args);
	}

}
