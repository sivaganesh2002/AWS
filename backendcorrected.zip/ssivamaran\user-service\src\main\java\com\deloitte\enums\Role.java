package com.deloitte.enums;

/**
 * The two roles described by the case study.
 *
 * <p>Persisted with {@code EnumType.ORDINAL} so the column stays a {@code TINYINT},
 * exactly as shown in the database design. Because the ordinal is what reaches the
 * database, new roles must always be appended at the end of this list, never inserted
 * in the middle.
 */
public enum Role {

	/** Creates and owns projects, creates issues and assigns them. Ordinal 0. */
	PROJECT_OWNER,

	/** Works on the issues assigned to them and updates their status. Ordinal 1. */
	ASSIGNEE
}
