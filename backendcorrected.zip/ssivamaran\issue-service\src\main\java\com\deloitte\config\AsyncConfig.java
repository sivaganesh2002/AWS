package com.deloitte.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Enables {@code @Async}, which is what lets {@link com.deloitte.event.IssueEventListener}
 * run off the request thread.
 *
 * <p>Without this annotation Spring would silently execute the listener synchronously.
 */
@Configuration
@EnableAsync
public class AsyncConfig {
}
