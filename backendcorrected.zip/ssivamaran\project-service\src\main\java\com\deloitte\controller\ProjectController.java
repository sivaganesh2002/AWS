package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.dto.Issue;
import com.deloitte.dto.ProjectRequest;
import com.deloitte.entity.Project;
import com.deloitte.service.ProjectService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/** REST endpoints of the Project Microservice (section 7.2 of the case study). */
@RestController
@RequestMapping("/api/projects")
@Tag(name = "Project Service", description = "Project creation, retrieval, update, deletion and issue aggregation")
public class ProjectController {

	@Autowired
	private ProjectService projectService;

	@Operation(summary = "Retrieve a list of all projects")
	@GetMapping
	public ResponseEntity<List<Project>> getAllProjects() {
		List<Project> projects = projectService.getAllProjects();
		if (projects.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(projects);
	}

	@Operation(summary = "Create a new project",
			description = "Checks the date range and confirms with the User Service that the owner is a PROJECT_OWNER.")
	@ApiResponses({
			@ApiResponse(responseCode = "201", description = "Project created"),
			@ApiResponse(responseCode = "400", description = "Validation failed or the owner is not valid") })
	@PostMapping
	public ResponseEntity<Project> createProject(@Valid @RequestBody ProjectRequest request) {
		Project created = projectService.createProject(request);
		return ResponseEntity.status(HttpStatus.CREATED).body(created);
	}

	@Operation(summary = "Retrieve details of a specific project by project ID")
	@GetMapping("/{projectId}")
	public ResponseEntity<Project> getProjectById(@PathVariable long projectId) {
		return ResponseEntity.ok(projectService.getProjectById(projectId));
	}

	@Operation(summary = "Update details of a specific project by project ID")
	@PutMapping("/{projectId}")
	public ResponseEntity<Project> updateProject(@PathVariable long projectId,
			@Valid @RequestBody ProjectRequest request) {
		return ResponseEntity.ok(projectService.updateProject(projectId, request));
	}

	@Operation(summary = "Delete a specific project by project ID")
	@DeleteMapping("/{projectId}")
	public ResponseEntity<Void> deleteProject(@PathVariable long projectId) {
		projectService.deleteProject(projectId);
		return ResponseEntity.noContent().build();
	}

	@Operation(summary = "Retrieve projects owned by a specific user by owner ID")
	@GetMapping("/owner/{ownerId}")
	public ResponseEntity<List<Project>> getProjectsByOwnerId(@PathVariable long ownerId) {
		List<Project> projects = projectService.getProjectsByOwnerId(ownerId);
		if (projects.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(projects);
	}

	// ---------------------------------------------------------------------
	// Inter service communication (Milestone 5)
	// ---------------------------------------------------------------------

	@Operation(summary = "Retrieve issues within a specific project by project ID",
			description = "Inter service communication - fetched from the Issue Service through Feign.")
	@GetMapping("/{projectId}/issues")
	public ResponseEntity<List<Issue>> getIssuesByProjectId(@PathVariable long projectId) {
		List<Issue> issues = projectService.getIssuesByProjectId(projectId);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Retrieve issues within a specific project by project name",
			description = "Inter service communication - the name is resolved locally, then the Issue Service is called.")
	@GetMapping("/projectName/{projectName}/issues")
	public ResponseEntity<List<Issue>> getIssuesByProjectName(@PathVariable String projectName) {
		List<Issue> issues = projectService.getIssuesByProjectName(projectName);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}
}
