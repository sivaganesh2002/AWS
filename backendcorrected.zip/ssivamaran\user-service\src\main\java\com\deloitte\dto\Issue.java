package com.deloitte.dto;

import java.time.LocalDate;

import lombok.Data;

/**
 * Local, read only view of an issue owned by the Issue Service.
 *
 * <p>Each microservice keeps its own copy of the shape it consumes rather than sharing a
 * common jar. That is intentional: it keeps the services independently deployable and stops
 * a change in one service's internals from forcing a rebuild of the others.
 */
@Data
public class Issue {

	private long id;
	private String summary;
	private String description;
	private String priority;
	private String status;
	private String type;
	private long projectId;
	private long assigneeId;
	private long createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
}
