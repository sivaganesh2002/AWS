package com.deloitte.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Payload for changing a password. The old password must be proved before the new one is stored. */
@Data
@NoArgsConstructor
@Schema(description = "Password change payload")
public class ChangePasswordRequest {

	@NotBlank(message = "oldPassword is required")
	@Schema(example = "Secret@123")
	private String oldPassword;

	@NotBlank(message = "newPassword is required")
	@Size(min = 6, message = "newPassword must be at least 6 characters")
	@Schema(example = "NewSecret@456")
	private String newPassword;
}
