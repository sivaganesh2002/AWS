package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.IssueDetailResponse;
import com.deloitte.dto.IssueRequest;
import com.deloitte.dto.StatusUpdateRequest;
import com.deloitte.entity.Issue;
import com.deloitte.enums.IssueType;
import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;

/** Business contract of the Issue Microservice. */
public interface IssueService {

	Issue createIssue(IssueRequest request);

	List<Issue> getAllIssues();

	Issue getIssueById(long issueId);

	Issue updateIssue(long issueId, IssueRequest request);

	/** The Assignee module's action: move an issue to a new status. */
	Issue updateStatus(long issueId, StatusUpdateRequest request);

	/** The Project Owner module's action: hand an issue to a different assignee. */
	Issue assignIssue(long issueId, long assigneeId);

	boolean deleteIssue(long issueId);

	List<Issue> getIssuesByProjectId(long projectId);

	List<Issue> getIssuesByAssigneeId(long assigneeId);

	List<Issue> getIssuesByOwnerId(long ownerId);

	List<Issue> search(Long projectId, Long assigneeId, Long createdBy, Status status, Priority priority,
			IssueType type);

	/** Inter service aggregation across the Project and User services. */
	IssueDetailResponse getIssueDetails(long issueId);
}
