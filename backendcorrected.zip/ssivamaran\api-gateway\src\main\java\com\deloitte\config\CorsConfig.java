package com.deloitte.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * Cross origin policy for the whole system.
 *
 * <p>The Angular UI is served from an S3 website endpoint, so every call it makes into the
 * gateway is cross origin. The auth interceptor also stamps X-User-Id and X-User-Role onto
 * each request, and a custom header makes the browser send a preflight OPTIONS first, so
 * the gateway has to answer that as well as the real call.
 *
 * <p>This is deliberately the only CORS configuration in the system. The downstream
 * services used to carry their own copy, but the gateway relays their response headers
 * verbatim, so keeping both produced two Access-Control-Allow-Origin headers on every
 * response and the browser rejects that outright.
 */
@Configuration
public class CorsConfig {

	@Bean
	@Order(Ordered.HIGHEST_PRECEDENCE)
	public CorsFilter corsFilter() {
		CorsConfiguration config = new CorsConfiguration();
		// allowedOriginPatterns rather than allowedOrigins: "*" together with
		// allowCredentials is rejected at startup by the stricter check.
		config.setAllowedOriginPatterns(List.of("*"));
		config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
		config.setAllowedHeaders(List.of("*"));
		config.setAllowCredentials(true);
		// Lets the browser cache the preflight for an hour instead of doubling every call.
		config.setMaxAge(3600L);

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
		return new CorsFilter(source);
	}
}
