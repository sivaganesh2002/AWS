package com.deloitte.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.Issue;

/**
 * Declarative HTTP client for the Issue Service.
 *
 * <p>{@code name = "issue-service"} is the Eureka application name, so Feign resolves and load
 * balances the call without any URL appearing in this codebase.
 */
@FeignClient(name = "issue-service", path = "/api/issues")
public interface IssueFeign {

	@GetMapping("/assignee/{assigneeId}")
	ResponseEntity<List<Issue>> getIssuesByAssigneeId(@PathVariable long assigneeId);

	@GetMapping("/owner/{ownerId}")
	ResponseEntity<List<Issue>> getIssuesByOwnerId(@PathVariable long ownerId);
}
