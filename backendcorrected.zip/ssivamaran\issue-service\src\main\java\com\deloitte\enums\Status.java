package com.deloitte.enums;

/**
 * Where an issue sits in its lifecycle.
 *
 * <p>The Assignee module of the case study is exactly the ability to move an issue along
 * this list, which the {@code PATCH /api/issues/{id}/status} endpoint provides.
 */
public enum Status {

	OPEN,
	IN_PROGRESS,
	IN_REVIEW,
	RESOLVED,
	CLOSED,
	REOPENED
}
