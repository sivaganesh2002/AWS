package com.deloitte.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.dto.Issue;

/**
 * Declarative HTTP client for the Issue Service.
 *
 * <p>Only the by-project lookup is declared. The Issue Service never calls back into this
 * endpoint, which keeps the two services free of any circular dependency.
 */
@FeignClient(name = "issue-service", path = "/api/issues")
public interface IssueFeign {

	@GetMapping("/project/{projectId}")
	ResponseEntity<List<Issue>> getIssuesByProjectId(@PathVariable long projectId);
}
