package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.dto.Issue;
import com.deloitte.dto.DashboardResponse;
import com.deloitte.dto.LoginRequest;
import com.deloitte.dto.LoginResponse;
import com.deloitte.dto.SignUpResponse;
import com.deloitte.dto.UserRequest;
import com.deloitte.entity.User;
import com.deloitte.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/**
 * REST endpoints of the User Microservice (section 7.1 of the case study).
 *
 * <p>Every method returns a {@link ResponseEntity} so the HTTP status code is chosen
 * explicitly rather than defaulting to 200 for everything.
 */
@RestController
@RequestMapping("/api/users")
@Tag(name = "User Service", description = "Sign up, login, roles and per user issue lookups")
public class UserController {

	@Autowired
	private UserService userService;

	@Operation(summary = "Retrieve a list of all users")
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		if (users.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(users);
	}

	@Operation(summary = "Create a new user",
			description = "Validates the payload, rejects a duplicate email and stores the password as a BCrypt hash.")
	@ApiResponses({
			@ApiResponse(responseCode = "201", description = "Account created"),
			@ApiResponse(responseCode = "400", description = "Validation failed"),
			@ApiResponse(responseCode = "409", description = "Email already registered") })
	@PostMapping
	public ResponseEntity<SignUpResponse> createUser(@Valid @RequestBody UserRequest request) {

		User created = userService.createUser(request);

		SignUpResponse body = new SignUpResponse("Your account is created successfully", "/api/users/login", created);
		return ResponseEntity.status(HttpStatus.CREATED).body(body);
	}

	@Operation(summary = "Authenticate a user and log them in",
			description = "Returns the role aware dashboard endpoint the client should navigate to next.")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Login successful"),
			@ApiResponse(responseCode = "401", description = "Invalid email or password") })
	@PostMapping("/login")
	public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {

		User user = userService.login(request);

		LoginResponse body = new LoginResponse("Login successful",
				"/api/users/" + user.getUserId() + "/dashboard", user);
		return ResponseEntity.ok(body);
	}

	@Operation(summary = "Retrieve details of a specific user by user ID")
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable long userId) {
		return ResponseEntity.ok(userService.getUserById(userId));
	}

	// ---------------------------------------------------------------------
	// Inter service communication (Milestone 5)
	// ---------------------------------------------------------------------

	@Operation(summary = "Retrieve issues assigned to a specific user by user ID",
			description = "Inter service communication - fetched from the Issue Service through Feign.")
	@GetMapping("/{userId}/issues")
	public ResponseEntity<List<Issue>> getIssuesByUserId(@PathVariable long userId) {
		List<Issue> issues = userService.getIssuesByUserId(userId);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Retrieve issues assigned to a specific user by username",
			description = "Inter service communication - the username is resolved locally, then the Issue Service is called.")
	@GetMapping("/username/{username}/issues")
	public ResponseEntity<List<Issue>> getIssuesByUsername(@PathVariable String username) {
		List<Issue> issues = userService.getIssuesByUsername(username);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Role aware dashboard for a user",
			description = "Aggregates the Project Service (RestTemplate) and the Issue Service (Feign) into one response. "
					+ "A PROJECT_OWNER sees owned projects and raised issues; an ASSIGNEE sees assigned issues.")
	@GetMapping("/{userId}/dashboard")
	public ResponseEntity<DashboardResponse> getDashboard(@PathVariable long userId) {
		return ResponseEntity.ok(userService.getDashboard(userId));
	}
}