package com.deloitte.exception;

/** Thrown when a user id or username does not exist. Mapped to HTTP 404. */
public class UserNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserNotFoundException(String message) {
		super(message);
	}
}
