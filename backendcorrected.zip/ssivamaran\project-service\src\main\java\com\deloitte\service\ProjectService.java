package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.Issue;
import com.deloitte.dto.ProjectRequest;
import com.deloitte.dto.ProjectSummary;
import com.deloitte.entity.Project;

/** Business contract of the Project Microservice. */
public interface ProjectService {

	Project createProject(ProjectRequest request);

	List<Project> getAllProjects();

	Project getProjectById(long projectId);

	Project getProjectByName(String projectName);

	List<Project> getProjectsByOwnerId(long ownerId);

	Project updateProject(long projectId, ProjectRequest request);

	boolean deleteProject(long projectId);

	/** Inter service call: issues belonging to a project, fetched from the Issue Service. */
	List<Issue> getIssuesByProjectId(long projectId);

	/** Inter service call: issues belonging to a project resolved by name. */
	List<Issue> getIssuesByProjectName(String projectName);

	/** Inter service aggregation across the User Service and the Issue Service. */
	ProjectSummary getProjectSummary(long projectId);
}
