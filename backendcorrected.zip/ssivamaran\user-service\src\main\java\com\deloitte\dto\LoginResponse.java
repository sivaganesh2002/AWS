package com.deloitte.dto;

import com.deloitte.entity.User;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Login confirmation.
 *
 * <p>{@code dashboardUrl} is derived from the user's role, which is how the case study
 * requirement "users are redirected to their respective dashboards based on their role"
 * is expressed in a REST API.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Result of a successful login")
public class LoginResponse {

	@Schema(example = "Login successful")
	private String message;

	@Schema(description = "Role aware landing endpoint", example = "/api/users/1001/dashboard")
	private String dashboardUrl;

	@Schema(description = "The authenticated user, without the password")
	private User user;
}
