package com.deloitte.dto;

import java.util.List;
import java.util.Map;

import com.deloitte.enums.Role;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * Role aware dashboard, assembled by calling the Project Service and the Issue Service.
 *
 * <p>A Project Owner sees the projects they own plus the issues they raised. An Assignee
 * sees only the issues assigned to them. Aggregating here rather than in the client means
 * one round trip instead of three.
 */
@Data
@Schema(description = "Summary shown to a user right after login")
public class DashboardResponse {

	private long userId;
	private String name;
	private Role role;

	@Schema(description = "Projects owned by this user. Always empty for an ASSIGNEE.")
	private List<Project> projects;

	@Schema(description = "Issues raised by a PROJECT_OWNER, or assigned to an ASSIGNEE")
	private List<Issue> issues;

	private int totalProjects;
	private int totalIssues;

	@Schema(description = "How many of the issues above sit in each status", example = "{\"OPEN\":3,\"IN_PROGRESS\":1}")
	private Map<String, Long> issueCountByStatus;
}
