package com.deloitte.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Reference listener for issue domain events.
 *
 * <p>Today it only writes an audit line. It exists to prove the seam: a notification module
 * would be added by dropping another {@code @EventListener} bean next to this one, and neither
 * the controller nor the service would need to change.
 *
 * <p>{@code @Async} keeps the listener off the request thread, so a slow notification can never
 * slow down the API call that triggered it.
 */
@Component
public class IssueEventListener {

	private static final Logger log = LoggerFactory.getLogger(IssueEventListener.class);

	@Async
	@EventListener
	public void onIssueStatusChanged(IssueStatusChangedEvent event) {

		log.info("AUDIT | issue {} '{}' moved {} -> {} by user {}", event.getIssueId(), event.getSummary(),
				event.getOldStatus(), event.getNewStatus(), event.getChangedBy());

		// Plug in here later, for example:
		//   notificationClient.notify(event.getAssigneeId(), "Your issue is now " + event.getNewStatus());
		//   webSocketBroker.send("/topic/issues/" + event.getIssueId(), event);
	}
}
