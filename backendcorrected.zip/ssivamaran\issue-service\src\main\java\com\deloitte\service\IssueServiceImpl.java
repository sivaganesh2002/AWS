package com.deloitte.service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deloitte.client.ProjectFeign;
import com.deloitte.client.UserFeign;
import com.deloitte.dto.IssueDetailResponse;
import com.deloitte.dto.IssueRequest;
import com.deloitte.dto.Project;
import com.deloitte.dto.StatusUpdateRequest;
import com.deloitte.dto.User;
import com.deloitte.entity.Issue;
import com.deloitte.enums.IssueType;
import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;
import com.deloitte.event.IssueStatusChangedEvent;
import com.deloitte.exception.InvalidIssueException;
import com.deloitte.exception.IssueNotFoundException;
import com.deloitte.repository.IssueRepository;

/**
 * Business logic of the Issue Microservice.
 *
 * <p>Two rules run through everything below:
 * <ul>
 *   <li>Writes are validated against the owning services. An issue may not point at a project
 *       or an assignee that does not exist, because nothing else in the system would catch it.</li>
 *   <li>Reads degrade rather than fail. If a decorating service is down the issue is still
 *       returned, just with fewer details.</li>
 * </ul>
 */
@Service
public class IssueServiceImpl implements IssueService {

	private static final Logger log = LoggerFactory.getLogger(IssueServiceImpl.class);

	@Autowired
	private IssueRepository issueRepository;

	@Autowired
	private ProjectFeign projectFeign;

	@Autowired
	private UserFeign userFeign;

	/** Used to announce status changes without knowing who, if anyone, is listening. */
	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Override
	public Issue createIssue(IssueRequest request) {

		requireProjectExists(request.getProjectId());
		if (request.getAssigneeId() != null && request.getAssigneeId() > 0) {
			requireUserExists(request.getAssigneeId(), "assigneeId");
		}
		if (request.getCreatedBy() != null && request.getCreatedBy() > 0) {
			requireUserExists(request.getCreatedBy(), "createdBy");
		}

		Issue issue = new Issue();
		issue.setSummary(request.getSummary().trim());
		issue.setDescription(request.getDescription());
		issue.setProjectId(request.getProjectId());
		issue.setAssigneeId(request.getAssigneeId() == null ? 0L : request.getAssigneeId());
		issue.setCreatedBy(request.getCreatedBy() == null ? 0L : request.getCreatedBy());

		// Sensible defaults keep the common "raise a quick bug" call down to three fields.
		issue.setPriority(request.getPriority() == null ? Priority.MEDIUM : request.getPriority());
		issue.setStatus(request.getStatus() == null ? Status.OPEN : request.getStatus());
		issue.setType(request.getType() == null ? IssueType.TASK : request.getType());

		issue.setSprint(request.getSprint());
		issue.setStoryPoint(request.getStoryPoint());
		issue.setTags(request.getTags());
		issue.setCreatedOn(LocalDate.now());
		issue.setLastUpdated(LocalDate.now());

		Issue saved = issueRepository.save(issue);
		log.info("Created issue {} in project {} assigned to {}", saved.getId(), saved.getProjectId(),
				saved.getAssigneeId());
		return saved;
	}

	@Override
	public List<Issue> getAllIssues() {
		return issueRepository.findAll();
	}

	@Override
	public Issue getIssueById(long issueId) {
		return issueRepository.findById(issueId)
				.orElseThrow(() -> new IssueNotFoundException("Issue with ID " + issueId + " not found."));
	}

	@Override
	public Issue updateIssue(long issueId, IssueRequest request) {

		Issue issue = getIssueById(issueId);
		Status oldStatus = issue.getStatus();

		requireProjectExists(request.getProjectId());
		if (request.getAssigneeId() != null && request.getAssigneeId() > 0) {
			requireUserExists(request.getAssigneeId(), "assigneeId");
		}

		issue.setSummary(request.getSummary().trim());
		issue.setDescription(request.getDescription());
		issue.setProjectId(request.getProjectId());

		if (request.getAssigneeId() != null) {
			issue.setAssigneeId(request.getAssigneeId());
		}
		if (request.getPriority() != null) {
			issue.setPriority(request.getPriority());
		}
		if (request.getStatus() != null) {
			issue.setStatus(request.getStatus());
		}
		if (request.getType() != null) {
			issue.setType(request.getType());
		}
		if (request.getSprint() != null) {
			issue.setSprint(request.getSprint());
		}
		if (request.getStoryPoint() != null) {
			issue.setStoryPoint(request.getStoryPoint());
		}
		if (request.getTags() != null) {
			issue.setTags(request.getTags());
		}

		issue.setLastUpdated(LocalDate.now());
		Issue saved = issueRepository.save(issue);

		publishIfStatusChanged(saved, oldStatus, request.getCreatedBy());
		return saved;
	}

	@Override
	public Issue updateStatus(long issueId, StatusUpdateRequest request) {

		Issue issue = getIssueById(issueId);
		Status oldStatus = issue.getStatus();

		if (oldStatus == request.getStatus()) {
			// Nothing changed, so nothing is written and no event is raised.
			return issue;
		}

		issue.setStatus(request.getStatus());
		issue.setLastUpdated(LocalDate.now());
		Issue saved = issueRepository.save(issue);

		publishIfStatusChanged(saved, oldStatus, request.getUpdatedBy());
		return saved;
	}

	@Override
	public Issue assignIssue(long issueId, long assigneeId) {

		Issue issue = getIssueById(issueId);
		requireUserExists(assigneeId, "assigneeId");

		issue.setAssigneeId(assigneeId);
		issue.setLastUpdated(LocalDate.now());

		log.info("Issue {} reassigned to user {}", issueId, assigneeId);
		return issueRepository.save(issue);
	}

	@Override
	public boolean deleteIssue(long issueId) {
		Issue issue = getIssueById(issueId);
		issueRepository.delete(issue);
		log.info("Deleted issue {}", issueId);
		return true;
	}

	@Override
	public List<Issue> getIssuesByProjectId(long projectId) {
		return issueRepository.findByProjectId(projectId);
	}

	@Override
	public List<Issue> getIssuesByAssigneeId(long assigneeId) {
		return issueRepository.findByAssigneeId(assigneeId);
	}

	@Override
	public List<Issue> getIssuesByOwnerId(long ownerId) {
		return issueRepository.findByCreatedBy(ownerId);
	}

	@Override
	public List<Issue> search(Long projectId, Long assigneeId, Long createdBy, Status status, Priority priority,
			IssueType type) {
		return issueRepository.search(projectId, assigneeId, createdBy, status, priority, type);
	}

	@Override
	public IssueDetailResponse getIssueDetails(long issueId) {

		Issue issue = getIssueById(issueId);

		IssueDetailResponse detail = new IssueDetailResponse();
		detail.setIssue(issue);
		detail.setProject(fetchProject(issue.getProjectId()));
		detail.setAssignee(issue.getAssigneeId() > 0 ? fetchUser(issue.getAssigneeId()) : null);
		detail.setReporter(issue.getCreatedBy() > 0 ? fetchUser(issue.getCreatedBy()) : null);

		return detail;
	}

	// ---------------------------------------------------------------------
	// Validation helpers - a definitive "does not exist" is fatal,
	// a transport failure is only logged.
	// ---------------------------------------------------------------------

	private void requireProjectExists(long projectId) {
		try {
			ResponseEntity<Project> response = projectFeign.getProjectById(projectId);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return;
			}
		} catch (Exception ex) {
			log.warn("Project Service unavailable while validating project {}. Proceeding without validation: {}",
					projectId, ex.getMessage());
			return;
		}
		throw new InvalidIssueException("No project exists with ID " + projectId + ".");
	}

	private void requireUserExists(long userId, String fieldName) {
		try {
			ResponseEntity<User> response = userFeign.getUserById(userId);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				return;
			}
		} catch (Exception ex) {
			log.warn("User Service unavailable while validating {} {}. Proceeding without validation: {}", fieldName,
					userId, ex.getMessage());
			return;
		}
		throw new InvalidIssueException("No user exists with ID " + userId + " for " + fieldName + ".");
	}

	// ---------------------------------------------------------------------
	// Read side decoration - never fatal
	// ---------------------------------------------------------------------

	private Project fetchProject(long projectId) {
		try {
			ResponseEntity<Project> response = projectFeign.getProjectById(projectId);
			if (response.getStatusCode().is2xxSuccessful()) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("Project Service unavailable while loading project {}: {}", projectId, ex.getMessage());
		}
		return null;
	}

	private User fetchUser(long userId) {
		try {
			ResponseEntity<User> response = userFeign.getUserById(userId);
			if (response.getStatusCode().is2xxSuccessful()) {
				return response.getBody();
			}
		} catch (Exception ex) {
			log.warn("User Service unavailable while loading user {}: {}", userId, ex.getMessage());
		}
		return null;
	}

	/**
	 * Announces a status transition so that notification and real time modules can be added
	 * later without this class changing.
	 */
	private void publishIfStatusChanged(Issue issue, Status oldStatus, Long changedBy) {

		if (oldStatus == issue.getStatus()) {
			return;
		}

		eventPublisher.publishEvent(new IssueStatusChangedEvent(issue.getId(), issue.getSummary(), oldStatus,
				issue.getStatus(), changedBy == null ? 0L : changedBy, issue.getAssigneeId(), issue.getCreatedBy()));
	}
}
