package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.dto.IssueRequest;
import com.deloitte.entity.Issue;
import com.deloitte.service.IssueService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/** REST endpoints of the Issue Microservice (section 7.3 of the case study). */
@RestController
@RequestMapping("/api/issues")
@Tag(name = "Issue Service", description = "Issue creation, retrieval, update, assignment and status tracking")
public class IssueController {

	@Autowired
	private IssueService issueService;

	@Operation(summary = "Retrieve a list of all issues")
	@GetMapping
	public ResponseEntity<List<Issue>> getAllIssues() {
		List<Issue> issues = issueService.getAllIssues();
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Create a new issue",
			description = "Confirms the project exists with the Project Service and the assignee exists with the User Service, "
					+ "then defaults priority to MEDIUM, status to OPEN and type to TASK when they are omitted.")
	@ApiResponses({
			@ApiResponse(responseCode = "201", description = "Issue created"),
			@ApiResponse(responseCode = "400", description = "Validation failed, or the project or assignee does not exist") })
	@PostMapping
	public ResponseEntity<Issue> createIssue(@Valid @RequestBody IssueRequest request) {
		Issue created = issueService.createIssue(request);
		return ResponseEntity.status(HttpStatus.CREATED).body(created);
	}

	@Operation(summary = "Retrieve details of a specific issue by issue ID")
	@GetMapping("/{id}")
	public ResponseEntity<Issue> getIssueById(@PathVariable long id) {
		return ResponseEntity.ok(issueService.getIssueById(id));
	}

	@Operation(summary = "Update details of a specific issue by issue ID")
	@PutMapping("/{id}")
	public ResponseEntity<Issue> updateIssue(@PathVariable long id, @Valid @RequestBody IssueRequest request) {
		return ResponseEntity.ok(issueService.updateIssue(id, request));
	}

	// ---------------------------------------------------------------------
	// Inter service communication (Milestone 5)
	// ---------------------------------------------------------------------

	@Operation(summary = "Retrieve issues within a specific project by project ID",
			description = "Inter service communication - called by the Project Service.")
	@GetMapping("/project/{projectId}")
	public ResponseEntity<List<Issue>> getIssuesByProjectId(@PathVariable long projectId) {
		List<Issue> issues = issueService.getIssuesByProjectId(projectId);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Retrieve issues raised by a specific user by owner ID",
			description = "Inter service communication - called by the User Service to build a Project Owner dashboard.")
	@GetMapping("/owner/{ownerId}")
	public ResponseEntity<List<Issue>> getIssuesByOwnerId(@PathVariable long ownerId) {
		List<Issue> issues = issueService.getIssuesByOwnerId(ownerId);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}

	@Operation(summary = "Retrieve issues assigned to a specific user by assignee ID",
			description = "Inter service communication - called by the User Service to build an Assignee dashboard.")
	@GetMapping("/assignee/{assigneeId}")
	public ResponseEntity<List<Issue>> getIssuesByAssigneeId(@PathVariable long assigneeId) {
		List<Issue> issues = issueService.getIssuesByAssigneeId(assigneeId);
		if (issues.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(issues);
	}
}