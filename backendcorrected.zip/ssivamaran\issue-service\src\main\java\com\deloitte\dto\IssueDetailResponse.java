package com.deloitte.dto;

import com.deloitte.entity.Issue;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * The "Issue Detail" screen of the case study, assembled in one response.
 *
 * <p>Every enriched field is nullable on purpose. If the User or Project Service is
 * momentarily unavailable the issue itself is still returned, just without that decoration.
 */
@Data
@Schema(description = "An issue enriched with its project and its people")
public class IssueDetailResponse {

	private Issue issue;

	@Schema(description = "Resolved from the Project Service")
	private Project project;

	@Schema(description = "Resolved from the User Service")
	private User assignee;

	@Schema(description = "Resolved from the User Service")
	private User reporter;
}
