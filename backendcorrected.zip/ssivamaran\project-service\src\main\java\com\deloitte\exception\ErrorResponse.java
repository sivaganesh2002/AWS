package com.deloitte.exception;

import java.time.LocalDateTime;
import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** The single error shape returned by every failing endpoint of this service. */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Standard error body")
public class ErrorResponse {

	@Schema(example = "2026-08-13T10:15:30")
	private LocalDateTime timestamp;

	@Schema(example = "404")
	private int status;

	@Schema(example = "Not Found")
	private String error;

	@Schema(example = "Project with ID 9999 not found.")
	private String message;

	@Schema(example = "/api/projects/9999")
	private String path;

	@Schema(description = "Field level validation errors, when applicable")
	private Map<String, String> validationErrors;

	public ErrorResponse(LocalDateTime timestamp, int status, String error, String message, String path) {
		this(timestamp, status, error, message, path, null);
	}
}
