package com.deloitte.dto;

import java.time.LocalDate;

import lombok.Data;

/** Local, read only view of an issue owned by the Issue Service. */
@Data
public class Issue {

	private long id;
	private String summary;
	private String description;
	private String priority;
	private String status;
	private String type;
	private long projectId;
	private long assigneeId;
	private long createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
}
