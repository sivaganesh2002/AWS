package com.deloitte.entity;

import com.deloitte.enums.Role;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A user of the Issue Tracking System, either a Project Owner or an Assignee.
 *
 * <p>Maps to the {@code user} table of the case study database design.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user", uniqueConstraints = @UniqueConstraint(name = "uk_user_email", columnNames = "email"))
@Schema(description = "A registered user of the Issue Tracking System")
public class User {

	@Id
	@TableGenerator(name = "user_gen", table = "id_generator",
			pkColumnName = "gen_name", valueColumnName = "gen_value",
			pkColumnValue = "user_id", initialValue = 1001, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "user_gen")
	@Column(name = "user_id")
	@Schema(description = "Generated identifier", example = "1001")
	private long userId;

	@Column(nullable = false)
	@Schema(description = "Display name, also used as the username", example = "Meera Iyer")
	private String name;

	@Column(nullable = false)
	@Schema(description = "Unique login email", example = "meera.iyer@example.com")
	private String email;

	/**
	 * BCrypt hash of the password.
	 *
	 * <p>{@code WRITE_ONLY} means Jackson will accept it on the way in but will never
	 * serialise it on the way out, so no API response can ever leak a credential.
	 */
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Column(nullable = false)
	@Schema(description = "Never returned by the API", accessMode = Schema.AccessMode.WRITE_ONLY)
	private String password;

	@Schema(description = "URL or path of the profile image", example = "https://cdn.example.com/avatars/meera.png")
	private String profile;

	/** Stored as TINYINT, matching the case study schema. */
	@Enumerated(EnumType.ORDINAL)
	@Column(columnDefinition = "TINYINT")
	@Schema(description = "PROJECT_OWNER or ASSIGNEE", example = "ASSIGNEE")
	private Role role;
}
