package com.deloitte.event;

import com.deloitte.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Published whenever an issue moves from one status to another.
 *
 * <p>This is the extension point the case study guidelines ask for. Real time updates,
 * targeted notifications or an audit trail can all be added later by writing a new
 * {@code @EventListener} - or by forwarding the event to Kafka or RabbitMQ - without a single
 * change to the service logic that raised it.
 */
@Data
@AllArgsConstructor
public class IssueStatusChangedEvent {

	private long issueId;
	private String summary;
	private Status oldStatus;
	private Status newStatus;

	/** The user who made the change, or 0 when the client did not identify itself. */
	private long changedBy;

	/** The assignee who should be notified. */
	private long assigneeId;

	/** The reporter who should be notified. */
	private long reporterId;
}
