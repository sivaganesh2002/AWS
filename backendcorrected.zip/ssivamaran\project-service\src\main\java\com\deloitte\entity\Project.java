package com.deloitte.entity;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A project owned by a Project Owner.
 *
 * <p>Maps to the {@code project} table of the case study database design. Note that
 * {@code projectOwner} is a plain user id and not a JPA relationship: the users live in a
 * different database owned by a different service, so the reference is kept loose on purpose.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "project")
@Schema(description = "A project tracked by the system")
public class Project {

	@Id
	@TableGenerator(name = "project_gen", table = "id_generator",
			pkColumnName = "gen_name", valueColumnName = "gen_value",
			pkColumnValue = "project_id", initialValue = 5001, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "project_gen")
	@Schema(description = "Generated identifier", example = "5001")
	private long id;

	@Column(name = "project_name", nullable = false)
	@Schema(example = "Payments Platform Revamp")
	private String projectName;

	/** User id of the owning Project Owner, resolved through the User Service. */
	@Column(name = "project_owner", nullable = false)
	@Schema(example = "1001")
	private long projectOwner;

	@Column(name = "start_date")
	@Schema(example = "2026-01-05")
	private LocalDate startDate;

	@Column(name = "end_date")
	@Schema(example = "2026-06-30")
	private LocalDate endDate;
}
