# Issue Tracking System — Angular front end

Week 3 case study. An Angular 22 single page application for the Issue Tracking System,
wired to the Spring Boot microservices built in Week 2 (`../issue-tracking-system`).

---

## Running it

The front end talks to the **API Gateway**, so start the backend in this order first:

| Order | Service           | Port | Notes                       |
| ----- | ----------------- | ---- | --------------------------- |
| 1     | `eureka-service`  | 8761 | Service registry            |
| 2     | `user-service`    | 8081 | Needs MySQL                 |
| 3     | `project-service` | 8082 | Needs MySQL                 |
| 4     | `issue-service`   | 8083 | Needs MySQL                 |
| 5     | `api-gateway`     | 8085 | The only port the UI knows  |

Then:

```bash
npm install
```

```bash
npm start
```

The app is served on <http://localhost:4200> and redirects to the login screen.

### Why there is no CORS setup

`ng serve` proxies every `/api/**` request to `http://localhost:8085` (see
`proxy.conf.json`), so during development the browser only ever talks to its own origin
and no preflight is involved. A production build has no proxy, so
`src/environments/environment.production.ts` points at the gateway by absolute URL —
change that value before deploying anywhere real.

### Build

```bash
npm run build
```

---

## Project structure

```
src/app/
├── core/                     singletons: models, HTTP services, guards, interceptors
│   ├── constants/            board columns, dropdown options
│   ├── guards/               authGuard, roleGuard
│   ├── interceptors/         stamps the signed in user onto every request
│   ├── models/               one interface per backend contract
│   └── services/             UserService, ProjectService, IssueService, AuthService,
│                             DashboardStore, NotificationService
├── shared/                   reusable, feature agnostic building blocks
│   ├── components/           board, issue-card, avatar, search-bar, field-error,
│   │                         empty-state, spinner, toast
│   ├── pipes/                dmyDate, statusLabel, priorityLabel, userName
│   ├── utils/                regex search matcher
│   └── validators/           prime number, no special chars, date range, image URL
├── layout/                   shell, sidebar, header
└── features/
    ├── auth/                 login (template driven), signup (reactive)
    ├── project-owner/        dashboard, create-project, create-issue,
    │                         issue-form (shared), issue-detail, edit-issue
    └── assignee/             dashboard, issue-detail
```

Every route is lazy loaded with `loadComponent`, so the login screen does not ship the
dashboards. Components are standalone; there are no NgModules.

---

## Screens and where they live

| Milestone | Screen                | Route                       | Forms            |
| --------- | --------------------- | --------------------------- | ---------------- |
| 1         | Login                 | `/login`                    | Template driven  |
| 1         | Signup                | `/signup`                   | Reactive         |
| 2         | Project Owner board   | `/owner/dashboard`          | —                |
| 3         | Create Project        | `/owner/projects/new`       | Reactive         |
| 4         | Create Issue          | `/owner/issues/new`         | Reactive         |
| 5         | Issue Details (owner) | `/owner/issues/:id`         | —                |
| 5         | Edit Issue            | `/owner/issues/:id/edit`    | Reactive         |
| 6         | Assignee board        | `/assignee/dashboard`       | —                |
| 6         | Issue Details         | `/assignee/issues/:id`      | Status dropdown  |

The case study asked for template driven forms on login and reactive forms everywhere
else, and that split is honoured exactly.

Create Issue and Edit Issue ask for the same ten fields under the same rules, so the form
itself is one reusable component (`features/project-owner/issue-form`); the two routes
differ only in the button label and in whether they POST or PUT.

---

## Backend endpoints consumed

All through the gateway, prefixed with `/api`.

| Method | Path                          | Used by                          |
| ------ | ----------------------------- | -------------------------------- |
| POST   | `/users/login`                | Login                            |
| POST   | `/users`                      | Signup                           |
| GET    | `/users`                      | Assignee and owner dropdowns     |
| GET    | `/users/{id}/dashboard`       | Both dashboards, sidebar counts  |
| GET    | `/projects/owner/{ownerId}`   | (available; dashboard uses the aggregate) |
| POST   | `/projects`                   | Create Project                   |
| GET    | `/issues/project/{projectId}` | Project Owner board              |
| GET    | `/issues/{id}`                | Both issue detail screens        |
| POST   | `/issues`                     | Create Issue                     |
| PUT    | `/issues/{id}`                | Edit Issue, assignee status save |

The PDF lists these paths under `/api/v1/...`. The Week 2 services actually publish them
under `/api/...`, and the running backend is what the UI is built against.

---

## Decisions worth knowing about

### Four board columns, six backend statuses

The case study shows four columns. The backend `Status` enum has six values. They are
mapped in one place, `core/constants/issue-board.constants.ts`:

| Column      | Backend statuses      | Written back as |
| ----------- | --------------------- | --------------- |
| TO DO       | `OPEN`, `REOPENED`    | `OPEN`          |
| DEVELOPMENT | `IN_PROGRESS`         | `IN_PROGRESS`   |
| TESTING     | `IN_REVIEW`           | `IN_REVIEW`     |
| COMPLETED   | `RESOLVED`, `CLOSED`  | `RESOLVED`      |

The six sets are disjoint and cover the whole enum, so no issue is dropped from the board
and none can appear twice. A status dropdown offers only the four canonical values, which
is why an issue stored as `CLOSED` displays as COMPLETED.

### Status updates send the whole issue

The Issue microservice exposes `PUT /api/issues/{id}` and no PATCH, so changing one field
means sending the full record back. `IssueService.changeStatus` rebuilds the payload from
the loaded issue so the Assignee screen cannot accidentally blank a field it does not
show.

### Authentication

The Week 2 backend verifies a BCrypt password and returns the user, but issues no token.
The session is therefore the user record itself, held in a signal and mirrored to
`localStorage` so a refresh does not sign the user out. `authGuard` and `roleGuard` keep
each role inside its own half of the app, and `authInterceptor` stamps `X-User-Id` and
`X-User-Role` onto every request — the hook to use the day real tokens are introduced.

The role dropdown on the login screen is verified against the account rather than trusted,
so signing in as the wrong role is refused instead of landing on an empty dashboard.

### Two places where the PDF contradicts itself

- **Summary length** — the Create Issue section says max 150, the validation table says
  min 5 / max 100. The validation table wins, since that is the section that is explicitly
  about validation.
- **Description** — the Create Issue section calls it optional, the validation table calls
  it required with min 10 / max 500. Again the validation table wins.

Both limits are stricter than the backend accepts, so nothing valid here is rejected there.

### Empty list responses

Every list endpoint answers `204 No Content` instead of `[]` when it has nothing to
return, which Angular delivers as `null`. The `orEmptyArray()` operator in
`core/services/http-helpers.ts` normalises that once, so no screen carries a null check.

---

## Notes

- TypeScript `strict` is on and the codebase contains no `any`.
- Searching and both dashboard filters run entirely in the browser over already fetched
  issues, as the case study requires. The search compiles the term as a regular
  expression; a half typed expression such as `bug (` falls back to a substring match
  instead of throwing on every keystroke.
- Unit test scaffolding was skipped (`--skip-tests`); the milestones do not ask for tests.
# week4-sivaganesh_sivamaran
