/**
 * Development environment settings.
 *
 * `apiBaseUrl` is deliberately a relative path. `ng serve` proxies every request that
 * starts with `/api` to the Spring Cloud Gateway on port 8085 (see `proxy.conf.json`),
 * so the browser only ever talks to its own origin and no CORS preflight is involved.
 */
export const environment = {
  /** False while running `ng serve`. */
  production: false,
  /** Root of every REST call. Proxied to the API Gateway during development. */
  apiBaseUrl: '/api',
} as const;
