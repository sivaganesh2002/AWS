/**
 * Production environment settings.
 *
 * A production bundle is served by a real web server rather than `ng serve`, so there is
 * no dev proxy any more and the gateway has to be addressed by its absolute URL.
 * Change this to the deployed gateway host before shipping.
 */
export const environment = {
  /** True in an optimised build. */
  production: true,
  /** Absolute root of the API Gateway. */
  apiBaseUrl: 'http://localhost:8085/api',
} as const;
