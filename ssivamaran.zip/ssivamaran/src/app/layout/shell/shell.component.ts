import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { DashboardStore } from '../../core/services/dashboard-store.service';
import { SidebarComponent } from '../sidebar/sidebar.component';

/**
 * Frame around every signed in screen: the sidebar on the left, the routed page on the
 * right.
 *
 * It also triggers the first dashboard load, so the sidebar counters are populated no
 * matter which screen the user lands on after a refresh.
 */
@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, SidebarComponent],
  templateUrl: './shell.component.html',
  styleUrl: './shell.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ShellComponent implements OnInit {
  /** Shared dashboard state. */
  private readonly store = inject(DashboardStore);

  /** Loads the dashboard once, unless a previous screen already did. */
  ngOnInit(): void {
    this.store.load();
  }
}
