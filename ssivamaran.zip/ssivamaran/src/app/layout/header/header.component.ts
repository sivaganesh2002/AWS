import { ChangeDetectionStrategy, Component, input, model } from '@angular/core';

import { SearchBarComponent } from '../../shared/components/search-bar/search-bar.component';

/**
 * The gold bar across the top of the content area.
 *
 * Carries the application name on the right and, on the two dashboards, the search field
 * on the left. Screens that have nothing to search (the create forms, the issue detail)
 * leave `showSearch` off and get the bar on its own.
 */
@Component({
  selector: 'app-header',
  imports: [SearchBarComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  /** Application name shown on the right. */
  readonly title = input('Issue Tracking System');

  /** Whether to render the search field on the left. */
  readonly showSearch = input(false);

  /** Two way bound search text, forwarded to the search bar. */
  readonly term = model('');
}
