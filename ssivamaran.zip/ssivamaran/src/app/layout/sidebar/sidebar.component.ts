import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { DashboardStore } from '../../core/services/dashboard-store.service';
import { AvatarComponent } from '../../shared/components/avatar/avatar.component';

/** One entry in the sidebar navigation. */
interface NavItem {
  /** Route to navigate to. */
  readonly link: string;
  /** Text shown to the user. */
  readonly label: string;
  /** Small coloured glyph on the left. */
  readonly icon: string;
}

/**
 * The dark navigation rail shown on every signed in screen.
 *
 * Shows the profile block, the counts the case study asks for, the navigation links for
 * the current role and the logout button. An Assignee gets no links because their
 * dashboard is the only screen they have.
 */
@Component({
  selector: 'app-sidebar',
  imports: [RouterLink, RouterLinkActive, AvatarComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SidebarComponent {
  /** Source of the signed in user. */
  private readonly auth = inject(AuthService);

  /** Router used by the logout button. */
  private readonly router = inject(Router);

  /** Shared dashboard state, read for the two counters. */
  protected readonly store = inject(DashboardStore);

  /** The signed in user. */
  protected readonly user = this.auth.currentUser;

  /** True when the signed in user owns projects. */
  protected readonly isProjectOwner = this.auth.isProjectOwner;

  /**
   * Navigation links for the current role.
   *
   * A Project Owner moves between the board and the two create screens; an Assignee only
   * ever sees their own board, so they get no links at all.
   */
  protected readonly navItems = computed<readonly NavItem[]>(() =>
    this.isProjectOwner()
      ? [
          { link: '/owner/dashboard', label: 'Project Dashboard', icon: '\u{1F4CB}' },
          { link: '/owner/projects/new', label: 'Create Project', icon: '\u{1F4C1}' },
          { link: '/owner/issues/new', label: 'Create Issue', icon: '\u{1F41E}' },
        ]
      : [],
  );

  /** Signs the user out, clears cached data and returns to the login screen. */
  protected logout(): void {
    this.auth.logout();
    this.store.clear();
    void this.router.navigate(['/login']);
  }
}
