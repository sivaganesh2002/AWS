import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Characters the case study allows in a project name and an issue summary:
 * letters, digits, spaces and the four punctuation marks `-`, `/`, `|` and `.`.
 */
const ALLOWED_TEXT = /^[A-Za-z0-9 \-/|.]+$/;

/** A URL that at least starts with http or https. */
const HTTP_URL = /^https?:\/\/\S+$/i;

/**
 * Rejects anything outside letters, digits, spaces and `-` `/` `|` `.`.
 *
 * Used by the project name and the issue summary.
 *
 * @returns a validator producing `{ specialChars: true }` when the value is not allowed
 */
export function noSpecialCharsValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value: unknown = control.value;
    // An empty control is the concern of Validators.required, not of this one.
    if (typeof value !== 'string' || value.trim().length === 0) {
      return null;
    }
    return ALLOWED_TEXT.test(value) ? null : { specialChars: true };
  };
}

/**
 * Decides whether a number is prime.
 *
 * Trial division stops at the square root because a composite number always has a factor
 * at or below it, which keeps the check cheap enough to run on every keystroke.
 *
 * @param value the number to test
 * @returns true when the value is a prime integer
 */
export function isPrime(value: number): boolean {
  if (!Number.isInteger(value) || value < 2) {
    return false;
  }
  if (value % 2 === 0) {
    return value === 2;
  }
  for (let divisor = 3; divisor * divisor <= value; divisor += 2) {
    if (value % divisor === 0) {
      return false;
    }
  }
  return true;
}

/**
 * Restricts story points to prime numbers, as the case study requires.
 *
 * @returns a validator producing `{ notPrime: true }` for any non prime value
 */
export function primeNumberValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value: unknown = control.value;
    if (value === null || value === '' || value === undefined) {
      return null;
    }
    const parsed = Number(value);
    return isPrime(parsed) ? null : { notPrime: true };
  };
}

/**
 * Restricts a control to positive whole numbers, used by the sprint field.
 *
 * @returns a validator producing `{ positiveInteger: true }` for anything else
 */
export function positiveIntegerValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value: unknown = control.value;
    if (value === null || value === '' || value === undefined) {
      return null;
    }
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed > 0 ? null : { positiveInteger: true };
  };
}

/**
 * Requires a well formed http or https URL, used by the profile image field.
 *
 * The check stops at the protocol and shape rather than demanding a `.png` or `.jpg`
 * suffix, because most avatar services (Gravatar and friends) serve images from
 * extensionless URLs and rejecting those would be wrong.
 *
 * @returns a validator producing `{ imageUrl: true }` for anything that is not a URL
 */
export function imageUrlValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value: unknown = control.value;
    if (typeof value !== 'string' || value.trim().length === 0) {
      return null;
    }
    return HTTP_URL.test(value.trim()) ? null : { imageUrl: true };
  };
}

/**
 * Cross field rule: the end date must not fall before the start date.
 *
 * Applied to the form group rather than to either control, because neither date can
 * judge itself. The error is also copied onto the end date control so the message can be
 * shown next to the field the user has to fix.
 *
 * @param startKey name of the start date control
 * @param endKey name of the end date control
 * @returns a group validator producing `{ dateRange: true }`
 */
export function dateRangeValidator(startKey: string, endKey: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const startControl = group.get(startKey);
    const endControl = group.get(endKey);

    if (!startControl || !endControl) {
      return null;
    }

    const start: unknown = startControl.value;
    const end: unknown = endControl.value;

    if (typeof start !== 'string' || typeof end !== 'string' || start === '' || end === '') {
      return null;
    }

    // ISO yyyy-MM-dd strings compare correctly with a plain string comparison, so there
    // is no need to build two Date objects on every keystroke.
    const invalid = end < start;

    // Keep any other error the control already has, only add or drop this one.
    const existing = { ...endControl.errors };
    if (invalid) {
      endControl.setErrors({ ...existing, dateRange: true });
    } else {
      delete existing['dateRange'];
      endControl.setErrors(Object.keys(existing).length > 0 ? existing : null);
    }

    return invalid ? { dateRange: true } : null;
  };
}
