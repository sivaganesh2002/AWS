import { Pipe, PipeTransform } from '@angular/core';

import { User } from '../../core/models/user.model';

/**
 * Turns a user id into a display name.
 *
 * Issues carry `assigneeId` and `createdBy` as bare numbers, so every screen that shows a
 * person needs this lookup. Passing the directory in as an argument keeps the pipe pure:
 * it recomputes when the id or the map reference changes and not otherwise.
 */
@Pipe({ name: 'userName' })
export class UserNamePipe implements PipeTransform {
  /**
   * @param userId identifier stored on the issue, 0 when unassigned
   * @param directory every known user, keyed by id
   * @param fallback text to show when the id is unknown or zero
   * @returns the display name of the user
   */
  transform(
    userId: number | null | undefined,
    directory: ReadonlyMap<number, User>,
    fallback = 'Unassigned',
  ): string {
    if (!userId) {
      return fallback;
    }
    return directory.get(userId)?.name ?? fallback;
  }
}
