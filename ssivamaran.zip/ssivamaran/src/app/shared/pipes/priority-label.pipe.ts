import { Pipe, PipeTransform } from '@angular/core';

import { IssuePriority } from '../../core/models/issue.model';

/** Title case labels for the priority constants. */
const LABELS: Readonly<Record<IssuePriority, string>> = {
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
  CRITICAL: 'Critical',
};

/** Renders a priority as the badge text used on issue cards. */
@Pipe({ name: 'priorityLabel' })
export class PriorityLabelPipe implements PipeTransform {
  /**
   * @param value priority of an issue
   * @returns the title case label, or a dash when the priority is missing
   */
  transform(value: IssuePriority | null | undefined): string {
    return value ? LABELS[value] : '-';
  }
}
