import { Pipe, PipeTransform } from '@angular/core';

/**
 * Renders a backend date as `dd-mm-yyyy`, the format the case study asks for.
 *
 * The backend sends plain ISO `yyyy-MM-dd` strings, so the parts are swapped directly
 * rather than going through `Date`. Building a `Date` from `2026-06-10` parses it as UTC
 * midnight, which shifts to the previous day for anyone west of Greenwich; slicing the
 * string avoids that class of off by one entirely.
 */
@Pipe({ name: 'dmyDate' })
export class DmyDatePipe implements PipeTransform {
  /**
   * @param value ISO date string, possibly with a time part, or null
   * @param fallback text to show when there is no date
   * @returns the date as dd-mm-yyyy
   */
  transform(value: string | null | undefined, fallback = '-'): string {
    if (!value) {
      return fallback;
    }

    const [datePart] = value.split('T');
    const [year, month, day] = datePart.split('-');

    if (!year || !month || !day) {
      return value;
    }

    return `${day}-${month}-${year}`;
  }
}
