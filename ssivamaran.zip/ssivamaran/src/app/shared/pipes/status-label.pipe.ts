import { Pipe, PipeTransform } from '@angular/core';

import { statusLabel } from '../../core/constants/issue-board.constants';
import { IssueStatus } from '../../core/models/issue.model';

/**
 * Shows a backend status using the board vocabulary.
 *
 * `IN_PROGRESS` becomes "DEVELOPMENT", `RESOLVED` becomes "COMPLETED", and so on, so a
 * user never sees two different words for the same thing.
 */
@Pipe({ name: 'statusLabel' })
export class StatusLabelPipe implements PipeTransform {
  /**
   * @param value backend status of an issue
   * @returns the label of the board column that status belongs to
   */
  transform(value: IssueStatus | null | undefined): string {
    return value ? statusLabel(value) : '-';
  }
}
