import { ChangeDetectionStrategy, Component, inject } from '@angular/core';

import { NotificationService } from '../../../core/services/notification.service';

/**
 * Renders whatever messages the `NotificationService` is currently holding.
 *
 * Mounted once by the root component so any screen can report success or failure without
 * carrying its own alert markup.
 */
@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrl: './toast.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ToastComponent {
  /** Source of the messages. Public so the template can read and dismiss them. */
  protected readonly notifications = inject(NotificationService);
}
