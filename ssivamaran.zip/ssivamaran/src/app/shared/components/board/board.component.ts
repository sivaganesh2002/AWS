import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';

import {
  BOARD_COLUMNS,
  BoardColumnKey,
  columnOf,
} from '../../../core/constants/issue-board.constants';
import { Issue } from '../../../core/models/issue.model';
import { User } from '../../../core/models/user.model';
import { IssueCardComponent } from '../issue-card/issue-card.component';

/**
 * The four column issue board shared by the Project Owner and Assignee dashboards.
 *
 * It receives an already filtered list and only decides which column each issue belongs
 * in, which keeps searching and filtering the concern of whichever dashboard is using it.
 */
@Component({
  selector: 'app-board',
  imports: [IssueCardComponent],
  templateUrl: './board.component.html',
  styleUrl: './board.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BoardComponent {
  /** Issues to display, already filtered by the parent. */
  readonly issues = input.required<readonly Issue[]>();

  /** Every known user, keyed by id, so a card can resolve its assignee. */
  readonly users = input.required<ReadonlyMap<number, User>>();

  /** Emitted when a card is opened. */
  readonly issueOpened = output<Issue>();

  /** Column definitions, in display order. */
  protected readonly columns = BOARD_COLUMNS;

  /**
   * Issues grouped by column.
   *
   * Recomputed as one pass over the list whenever the input changes, rather than
   * filtering the array once per column, so a board with many issues stays cheap while
   * the user types in the search box.
   */
  protected readonly grouped = computed<ReadonlyMap<BoardColumnKey, Issue[]>>(() => {
    const buckets = new Map<BoardColumnKey, Issue[]>(
      BOARD_COLUMNS.map((column) => [column.key, [] as Issue[]]),
    );

    for (const issue of this.issues()) {
      buckets.get(columnOf(issue.status))?.push(issue);
    }

    return buckets;
  });

  /**
   * Issues sitting in one column.
   *
   * @param key the column to read
   * @returns the issues in that column, never null
   */
  protected issuesIn(key: BoardColumnKey): readonly Issue[] {
    return this.grouped().get(key) ?? [];
  }

  /**
   * Resolves the assignee of an issue.
   *
   * @param issue the issue being rendered
   * @returns the assignee, or null when the issue is unassigned or the user is unknown
   */
  protected assigneeOf(issue: Issue): User | null {
    return this.users().get(issue.assigneeId) ?? null;
  }
}
