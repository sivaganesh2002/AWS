import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * The "nothing here yet" placeholder.
 *
 * Covers both flavours the case study asks for: a plain message, and the
 * "No Projects Available" screen that also offers a Create Project link.
 */
@Component({
  selector: 'app-empty-state',
  imports: [RouterLink],
  templateUrl: './empty-state.component.html',
  styleUrl: './empty-state.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EmptyStateComponent {
  /** Message shown to the user. */
  readonly message = input.required<string>();

  /** Label of the optional call to action. Omit to show the message alone. */
  readonly actionLabel = input<string | null>(null);

  /** Route the call to action navigates to. */
  readonly actionLink = input<string | null>(null);
}
