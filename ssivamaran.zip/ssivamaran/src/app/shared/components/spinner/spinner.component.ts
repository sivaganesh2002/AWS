import { ChangeDetectionStrategy, Component, input } from '@angular/core';

/** Centred loading indicator shown while a screen waits for the API. */
@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrl: './spinner.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SpinnerComponent {
  /** Text shown under the spinner. */
  readonly label = input('Loading...');
}
