import { ChangeDetectionStrategy, Component, input, model } from '@angular/core';
import { FormsModule } from '@angular/forms';

/**
 * The search field that sits in the gold header on both dashboards.
 *
 * The text is exposed as a `model`, so a parent binds it with `[(term)]` and gets a
 * signal it can feed straight into a `computed` filter. The component itself does no
 * filtering, which is what lets both dashboards reuse it unchanged.
 */
@Component({
  selector: 'app-search-bar',
  imports: [FormsModule],
  templateUrl: './search-bar.component.html',
  styleUrl: './search-bar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SearchBarComponent {
  /** Two way bound search text. */
  readonly term = model('');

  /** Placeholder shown while the field is empty. */
  readonly placeholder = input('Search issue by summary or description');
}
