import { ChangeDetectionStrategy, Component, computed, input, signal } from '@angular/core';

/**
 * Circular profile picture with a readable fallback.
 *
 * Profile images are user supplied URLs that may 404 or point at nothing at all, so the
 * component quietly degrades to the initials rather than leaving a broken image icon on
 * the board.
 */
@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrl: './avatar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvatarComponent {
  /** Name of the person, used for the initials and the alt text. */
  readonly name = input.required<string>();

  /** Profile image URL. Null or empty falls straight through to the initials. */
  readonly src = input<string | null>(null);

  /** Diameter in pixels. */
  readonly size = input(26);

  /** Set once the browser reports the image could not be loaded. */
  protected readonly loadFailed = signal(false);

  /** True while there is a URL worth trying. */
  protected readonly showImage = computed(() => {
    const url = this.src();
    return !this.loadFailed() && typeof url === 'string' && url.trim().length > 0;
  });

  /** First letters of the first two words of the name, for example "Antonia Christie" to "AC". */
  protected readonly initials = computed(() =>
    this.name()
      .split(' ')
      .filter((part) => part.length > 0)
      .slice(0, 2)
      .map((part) => part[0].toUpperCase())
      .join(''),
  );

  /** Switches to the initials when the image fails to load. */
  protected onError(): void {
    this.loadFailed.set(true);
  }
}
