import { Component, input } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';

/**
 * Renders the validation message for one form control.
 *
 * Every screen shows validation the same way, so the wording lives here once instead of
 * being repeated as a stack of `@if` blocks under each field. It works for both the
 * template driven login form and the reactive forms, because it only needs an
 * `AbstractControl`.
 */
@Component({
  selector: 'app-field-error',
  templateUrl: './field-error.component.html',
  styleUrl: './field-error.component.scss',
  // Default change detection on purpose. `AbstractControl` validity is not signal based,
  // so under OnPush this component would never be re-checked while the user types and the
  // message would go stale.
})
export class FieldErrorComponent {
  /** The control to report on. Null is accepted so templates never need a guard. */
  readonly control = input.required<AbstractControl | null | undefined>();

  /** Field name used in the messages, for example "Email address". */
  readonly label = input('This field');

  /**
   * The message to show, or null when the field is fine or has not been touched yet.
   *
   * Deliberately a getter rather than a `computed`, because `AbstractControl` is not
   * signal based: its validity changes without notifying any signal, so the value has to
   * be read fresh on each change detection pass.
   */
  protected get message(): string | null {
    const control = this.control();

    if (!control || control.valid || !(control.dirty || control.touched)) {
      return null;
    }

    return this.describe(control.errors ?? {});
  }

  /**
   * Maps the first failing rule to a sentence.
   *
   * Only the first error is reported: showing three messages at once for an empty field
   * is noise, and fixing the first usually clears the rest.
   *
   * @param errors the error map Angular put on the control
   * @returns a human readable explanation
   */
  private describe(errors: ValidationErrors): string {
    const label = this.label();

    if (errors['required']) {
      return `${label} is required.`;
    }
    if (errors['email']) {
      return 'Enter a valid email address.';
    }
    if (errors['minlength']) {
      const rule = errors['minlength'] as { requiredLength: number };
      return `${label} must be at least ${rule.requiredLength} characters.`;
    }
    if (errors['maxlength']) {
      const rule = errors['maxlength'] as { requiredLength: number };
      return `${label} must not exceed ${rule.requiredLength} characters.`;
    }
    if (errors['specialChars']) {
      return `${label} may only contain letters, numbers and - / | .`;
    }
    if (errors['notPrime']) {
      return 'Story points must be a prime number (2, 3, 5, 7, 11, ...).';
    }
    if (errors['positiveInteger']) {
      return `${label} must be a whole number greater than 0.`;
    }
    if (errors['imageUrl']) {
      return 'Enter a valid image URL starting with http:// or https://.';
    }
    if (errors['dateRange']) {
      return 'End date cannot be earlier than the start date.';
    }
    if (errors['min']) {
      const rule = errors['min'] as { min: number };
      return `${label} must be at least ${rule.min}.`;
    }

    return `${label} is not valid.`;
  }
}
