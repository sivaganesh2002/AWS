import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';

import { Issue } from '../../../core/models/issue.model';
import { User } from '../../../core/models/user.model';
import { DmyDatePipe } from '../../pipes/dmy-date.pipe';
import { PriorityLabelPipe } from '../../pipes/priority-label.pipe';
import { AvatarComponent } from '../avatar/avatar.component';

/**
 * One issue as it appears in a board column.
 *
 * Shows exactly the fields the case study lists for a card: id, creation date, title,
 * description, and the assignee name, photo and priority. Clicking it asks the parent to
 * open the detail screen, so the same card works on both dashboards even though they
 * navigate to different routes.
 */
@Component({
  selector: 'app-issue-card',
  imports: [AvatarComponent, DmyDatePipe, PriorityLabelPipe],
  templateUrl: './issue-card.component.html',
  styleUrl: './issue-card.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IssueCardComponent {
  /** The issue to render. */
  readonly issue = input.required<Issue>();

  /** The assignee, resolved by the parent. Null when the issue is unassigned. */
  readonly assignee = input<User | null>(null);

  /** Emitted when the user clicks or keyboard activates the card. */
  readonly opened = output<Issue>();

  /** Name shown in the card footer. */
  protected readonly assigneeName = computed(() => this.assignee()?.name ?? 'Unassigned');

  /** CSS class that colours the priority badge, for example `badge-high`. */
  protected readonly priorityClass = computed(
    () => `badge badge-${this.issue().priority.toLowerCase()}`,
  );

  /** Raises `opened` for the parent to handle. */
  protected open(): void {
    this.opened.emit(this.issue());
  }
}
