import { Issue } from '../../core/models/issue.model';

/**
 * Builds the predicate behind the header search box.
 *
 * The case study asks for a regular expression match against the summary and the
 * description, so the term is compiled as a `RegExp`. A user typing a half finished
 * expression such as `bug (` would otherwise throw a `SyntaxError` on every keystroke, so
 * an uncompilable term quietly degrades to a case insensitive substring search instead.
 *
 * @param term raw text from the search box
 * @returns a predicate that is true for issues the user should still see
 */
export function buildIssueMatcher(term: string): (issue: Issue) => boolean {
  const trimmed = term.trim();

  // An empty box means no filtering at all.
  if (trimmed.length === 0) {
    return () => true;
  }

  try {
    const pattern = new RegExp(trimmed, 'i');
    return (issue) => pattern.test(issue.summary) || pattern.test(issue.description ?? '');
  } catch {
    const needle = trimmed.toLowerCase();
    return (issue) =>
      issue.summary.toLowerCase().includes(needle) ||
      (issue.description ?? '').toLowerCase().includes(needle);
  }
}
