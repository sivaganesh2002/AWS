import { Injectable, computed, inject, signal } from '@angular/core';
import { forkJoin } from 'rxjs';

import { DashboardResponse } from '../models/dashboard.model';
import { User } from '../models/user.model';
import { AuthService } from './auth.service';
import { toUserMessage } from './http-helpers';
import { UserService } from './user.service';

/**
 * Shared state behind the sidebar and both dashboards.
 *
 * The sidebar lives in the shell, outside the routed page, but has to show the same
 * project and issue counts the dashboard does. Holding that one aggregated response here
 * means the numbers cannot drift apart and the app makes one request instead of two.
 * Screens that create something call `reload` so the counts update immediately.
 */
@Injectable({ providedIn: 'root' })
export class DashboardStore {
  /** Client over the User microservice. */
  private readonly userService = inject(UserService);

  /** Source of the signed in user. */
  private readonly auth = inject(AuthService);

  /** Last aggregated dashboard payload, or null before the first load. */
  private readonly dashboard = signal<DashboardResponse | null>(null);

  /** Every known user, keyed by id, so any screen can resolve an assignee name. */
  private readonly userDirectory = signal<ReadonlyMap<number, User>>(new Map());

  /** True while a load is in flight. */
  readonly loading = signal(false);

  /** Message from the last failed load, or null. */
  readonly error = signal<string | null>(null);

  /** Read only view of the user directory. */
  readonly users = this.userDirectory.asReadonly();

  /** Projects owned by the signed in user. Always empty for an Assignee. */
  readonly projects = computed(() => this.dashboard()?.projects ?? []);

  /** Issues raised by a Project Owner, or assigned to an Assignee. */
  readonly issues = computed(() => this.dashboard()?.issues ?? []);

  /** Number shown in the sidebar under "Projects Created". */
  readonly totalProjects = computed(() => this.dashboard()?.totalProjects ?? 0);

  /** Number shown in the sidebar under "Issues Created" or "Issues Assigned". */
  readonly totalIssues = computed(() => this.dashboard()?.totalIssues ?? 0);

  /** True once a payload has arrived, used to tell "empty" apart from "not loaded yet". */
  readonly loaded = computed(() => this.dashboard() !== null);

  /**
   * Loads the dashboard and the user directory for the signed in user.
   *
   * Both are fetched together because every board card needs a name and a photo that only
   * the user list can supply. Does nothing when nobody is signed in.
   *
   * @param force reload even when a payload is already cached
   */
  load(force = false): void {
    const user = this.auth.currentUser();
    if (user === null || this.loading()) {
      return;
    }
    if (this.loaded() && !force) {
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    forkJoin({
      dashboard: this.userService.getDashboard(user.userId),
      users: this.userService.getAll(),
    }).subscribe({
      next: ({ dashboard, users }) => {
        this.dashboard.set(dashboard);
        this.userDirectory.set(new Map(users.map((entry) => [entry.userId, entry])));
        this.loading.set(false);
      },
      error: (failure: unknown) => {
        this.error.set(toUserMessage(failure));
        this.loading.set(false);
      },
    });
  }

  /** Fetches the dashboard again, for example after a project or issue is created. */
  reload(): void {
    this.load(true);
  }

  /** Drops everything. Called on logout so the next user never sees stale numbers. */
  clear(): void {
    this.dashboard.set(null);
    this.userDirectory.set(new Map());
    this.error.set(null);
  }
}
