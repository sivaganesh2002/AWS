import { HttpErrorResponse } from '@angular/common/http';
import { OperatorFunction, map } from 'rxjs';

import { ApiError } from '../models/api-error.model';

/**
 * Turns a `204 No Content` response into an empty array.
 *
 * Every list endpoint in this backend answers 204 rather than `[]` when it has nothing
 * to return, and Angular hands a 204 body to the caller as `null`. Without this operator
 * every consumer would need its own null check before iterating.
 *
 * @returns an operator that substitutes an empty array for a null body
 */
export function orEmptyArray<T>(): OperatorFunction<T[] | null, T[]> {
  return map((body) => body ?? []);
}

/**
 * Type guard for the backend error envelope.
 *
 * @param body the parsed error body of a failed response
 * @returns true when the body carries the fields of an ApiError
 */
function isApiError(body: unknown): body is ApiError {
  return (
    typeof body === 'object' &&
    body !== null &&
    typeof (body as ApiError).message === 'string' &&
    typeof (body as ApiError).status === 'number'
  );
}

/**
 * Extracts the most useful message out of a failed HTTP call.
 *
 * Field level validation errors are preferred over the generic summary, because
 * "email must be a valid email address" tells the user far more than "Validation failed".
 *
 * @param error the failure raised by HttpClient
 * @returns a message fit to show in a toast
 */
export function toUserMessage(error: unknown): string {
  // Not every failure comes from the network: AuthService raises a plain Error when the
  // role picked on the login form does not match the account. Its message is already
  // written for the user, so pass it straight through.
  if (!(error instanceof HttpErrorResponse)) {
    return error instanceof Error ? error.message : 'Something went wrong. Please try again.';
  }

  // Status 0 means the request never reached a server: nothing is listening on the port.
  if (error.status === 0) {
    return 'Cannot reach the API Gateway. Make sure the backend is running on port 8085.';
  }

  const body: unknown = error.error;
  if (isApiError(body)) {
    const fieldErrors = body.validationErrors;
    if (fieldErrors && Object.keys(fieldErrors).length > 0) {
      return Object.entries(fieldErrors)
        .map(([field, reason]) => `${field}: ${reason}`)
        .join('. ');
    }
    return body.message;
  }

  return error.message || 'Something went wrong. Please try again.';
}
