import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Issue } from '../models/issue.model';
import { Project, ProjectRequest } from '../models/project.model';
import { orEmptyArray } from './http-helpers';

/** Fully typed client over the Project microservice. */
@Injectable({ providedIn: 'root' })
export class ProjectService {
  /** Angular HTTP client. */
  private readonly http = inject(HttpClient);

  /** Root of every project endpoint, for example `/api/projects`. */
  private readonly baseUrl = `${environment.apiBaseUrl}/projects`;

  /**
   * Every project in the system.
   *
   * @returns the full project list, empty when the service answers 204
   */
  getAll(): Observable<Project[]> {
    return this.http.get<Project[] | null>(this.baseUrl).pipe(orEmptyArray());
  }

  /**
   * Looks up a single project.
   *
   * @param projectId generated identifier of the project
   * @returns the matching project
   */
  getById(projectId: number): Observable<Project> {
    return this.http.get<Project>(`${this.baseUrl}/${projectId}`);
  }

  /**
   * Projects owned by one Project Owner. Backs the dashboard dropdown.
   *
   * @param ownerId user id of the Project Owner
   * @returns their projects, empty when the service answers 204
   */
  getByOwner(ownerId: number): Observable<Project[]> {
    return this.http.get<Project[] | null>(`${this.baseUrl}/owner/${ownerId}`).pipe(orEmptyArray());
  }

  /**
   * Creates a project.
   *
   * @param request the create form payload
   * @returns the persisted project, including its generated id
   */
  create(request: ProjectRequest): Observable<Project> {
    return this.http.post<Project>(this.baseUrl, request);
  }

  /**
   * Replaces a project.
   *
   * @param projectId project to overwrite
   * @param request the full new state of the project
   * @returns the updated project
   */
  update(projectId: number, request: ProjectRequest): Observable<Project> {
    return this.http.put<Project>(`${this.baseUrl}/${projectId}`, request);
  }

  /**
   * Deletes a project.
   *
   * @param projectId project to remove
   * @returns an empty response
   */
  delete(projectId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${projectId}`);
  }

  /**
   * Issues belonging to a project, resolved by the backend through Feign.
   *
   * @param projectId the project whose board is being drawn
   * @returns its issues, empty when the service answers 204
   */
  getIssues(projectId: number): Observable<Issue[]> {
    return this.http.get<Issue[] | null>(`${this.baseUrl}/${projectId}/issues`).pipe(orEmptyArray());
  }
}
