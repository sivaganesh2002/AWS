import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { DashboardResponse } from '../models/dashboard.model';
import { Issue } from '../models/issue.model';
import {
  LoginRequest,
  LoginResponse,
  SignUpRequest,
  SignUpResponse,
  User,
} from '../models/user.model';
import { orEmptyArray } from './http-helpers';

/** Fully typed client over the User microservice. */
@Injectable({ providedIn: 'root' })
export class UserService {
  /** Angular HTTP client, injected without a constructor. */
  private readonly http = inject(HttpClient);

  /** Root of every user endpoint, for example `/api/users`. */
  private readonly baseUrl = `${environment.apiBaseUrl}/users`;

  /**
   * Every registered user. Backs the assignee and project owner dropdowns.
   *
   * @returns the full user list, empty when the service answers 204
   */
  getAll(): Observable<User[]> {
    return this.http.get<User[] | null>(this.baseUrl).pipe(orEmptyArray());
  }

  /**
   * Looks up a single user.
   *
   * @param userId generated identifier of the user
   * @returns the matching user
   */
  getById(userId: number): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/${userId}`);
  }

  /**
   * Registers a new account.
   *
   * @param request the signup form payload
   * @returns the confirmation message and the created user
   */
  signUp(request: SignUpRequest): Observable<SignUpResponse> {
    return this.http.post<SignUpResponse>(this.baseUrl, request);
  }

  /**
   * Verifies credentials against the stored BCrypt hash.
   *
   * @param request the email and password typed on the login form
   * @returns the authenticated user and the dashboard the backend suggests
   */
  login(request: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, request);
  }

  /**
   * Role aware landing payload, aggregated by the backend across all three services.
   *
   * @param userId the signed in user
   * @returns projects and issues plus the counts shown in the sidebar
   */
  getDashboard(userId: number): Observable<DashboardResponse> {
    return this.http.get<DashboardResponse>(`${this.baseUrl}/${userId}/dashboard`);
  }

  /**
   * Issues assigned to a user.
   *
   * @param userId the assignee
   * @returns their issues, empty when the service answers 204
   */
  getIssues(userId: number): Observable<Issue[]> {
    return this.http.get<Issue[] | null>(`${this.baseUrl}/${userId}/issues`).pipe(orEmptyArray());
  }
}
