import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, map } from 'rxjs';

import { LoginRequest, Role, SignUpRequest, SignUpResponse, User } from '../models/user.model';
import { UserService } from './user.service';

/** Key the session is stored under in `localStorage`. */
const SESSION_KEY = 'issue-tracker.session';

/**
 * Holds the signed in user and decides where each role is allowed to go.
 *
 * The Week 2 backend authenticates with a BCrypt check and returns the user, but it
 * issues no token, so there is nothing to renew or expire. The session is therefore the
 * user record itself, kept in a signal for the templates and mirrored into
 * `localStorage` so a page refresh does not sign the user out.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  /** Client over the User microservice. */
  private readonly userService = inject(UserService);

  /** The signed in user, or null when nobody is signed in. */
  private readonly session = signal<User | null>(this.restore());

  /** Read only view of the session for templates and guards. */
  readonly currentUser = this.session.asReadonly();

  /** True once a user has signed in. */
  readonly isAuthenticated = computed(() => this.session() !== null);

  /** Role of the signed in user, or null when nobody is signed in. */
  readonly role = computed<Role | null>(() => this.session()?.role ?? null);

  /** True when the signed in user owns projects rather than working on issues. */
  readonly isProjectOwner = computed(() => this.role() === 'PROJECT_OWNER');

  /** Route the signed in user belongs on, used after login and by the guards. */
  readonly homeRoute = computed(() =>
    this.isProjectOwner() ? '/owner/dashboard' : '/assignee/dashboard',
  );

  /**
   * Signs a user in and stores the session.
   *
   * The login screen also asks which role the user is signing in as. That choice is
   * verified against the account here rather than trusted, so an Assignee who picks
   * Project Owner is refused instead of landing on a dashboard with no data.
   *
   * @param credentials email and password typed on the form
   * @param expectedRole the role selected on the form
   * @returns the authenticated user
   * @throws Error when the account exists but holds a different role
   */
  login(credentials: LoginRequest, expectedRole: Role): Observable<User> {
    return this.userService.login(credentials).pipe(
      map((response) => {
        if (response.user.role !== expectedRole) {
          // Thrown inside map so it surfaces on the error channel like an HTTP failure,
          // which lets the component handle both in one place.
          throw new Error(
            `This account is registered as ${AuthService.readableRole(response.user.role)}. Select that role to sign in.`,
          );
        }
        this.store(response.user);
        // Unwrap the envelope so callers receive the user they actually care about.
        return response.user;
      }),
    );
  }

  /**
   * Registers a new account. The user still has to sign in afterwards.
   *
   * @param request the signup form payload
   * @returns the confirmation message and the created user
   */
  signUp(request: SignUpRequest): Observable<SignUpResponse> {
    return this.userService.signUp(request);
  }

  /** Clears the session. The caller is responsible for navigating away. */
  logout(): void {
    this.session.set(null);
    localStorage.removeItem(SESSION_KEY);
  }

  /**
   * Replaces the cached user, for example after a profile changes.
   *
   * @param user the fresh user record
   */
  refresh(user: User): void {
    this.store(user);
  }

  /**
   * Turns a role constant into something worth showing a user.
   *
   * @param role the stored role
   * @returns the label used on the login and signup dropdowns
   */
  static readableRole(role: Role): string {
    return role === 'PROJECT_OWNER' ? 'Project Owner' : 'Assignee';
  }

  /**
   * Writes the session to both the signal and `localStorage`.
   *
   * @param user the authenticated user
   */
  private store(user: User): void {
    this.session.set(user);
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }

  /**
   * Reads a session left behind by a previous visit.
   *
   * @returns the stored user, or null when there is none or the entry is unreadable
   */
  private restore(): User | null {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw === null) {
      return null;
    }
    try {
      return JSON.parse(raw) as User;
    } catch {
      // A corrupted entry should sign the user out rather than break every screen.
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
  }
}
