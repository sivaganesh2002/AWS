import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Issue, IssueRequest, IssueStatus } from '../models/issue.model';
import { orEmptyArray } from './http-helpers';

/** Fully typed client over the Issue microservice. */
@Injectable({ providedIn: 'root' })
export class IssueService {
  /** Angular HTTP client. */
  private readonly http = inject(HttpClient);

  /** Root of every issue endpoint, for example `/api/issues`. */
  private readonly baseUrl = `${environment.apiBaseUrl}/issues`;

  /**
   * Every issue in the system.
   *
   * @returns the full issue list, empty when the service answers 204
   */
  getAll(): Observable<Issue[]> {
    return this.http.get<Issue[] | null>(this.baseUrl).pipe(orEmptyArray());
  }

  /**
   * Looks up a single issue.
   *
   * @param issueId generated identifier of the issue
   * @returns the matching issue
   */
  getById(issueId: number): Observable<Issue> {
    return this.http.get<Issue>(`${this.baseUrl}/${issueId}`);
  }

  /**
   * Raises a new issue.
   *
   * @param request the create form payload
   * @returns the persisted issue, including its generated id
   */
  create(request: IssueRequest): Observable<Issue> {
    return this.http.post<Issue>(this.baseUrl, request);
  }

  /**
   * Replaces an issue. The backend has no PATCH, so this is a full overwrite.
   *
   * @param issueId issue to overwrite
   * @param request the full new state of the issue
   * @returns the updated issue
   */
  update(issueId: number, request: IssueRequest): Observable<Issue> {
    return this.http.put<Issue>(`${this.baseUrl}/${issueId}`, request);
  }

  /**
   * Issues raised against one project. Backs the Project Owner board.
   *
   * @param projectId the selected project
   * @returns its issues, empty when the service answers 204
   */
  getByProject(projectId: number): Observable<Issue[]> {
    return this.http.get<Issue[] | null>(`${this.baseUrl}/project/${projectId}`).pipe(orEmptyArray());
  }

  /**
   * Issues raised by one user.
   *
   * @param ownerId the reporter, normally a Project Owner
   * @returns their issues, empty when the service answers 204
   */
  getByOwner(ownerId: number): Observable<Issue[]> {
    return this.http.get<Issue[] | null>(`${this.baseUrl}/owner/${ownerId}`).pipe(orEmptyArray());
  }

  /**
   * Issues assigned to one user. Backs the Assignee board.
   *
   * @param assigneeId the assignee
   * @returns their issues, empty when the service answers 204
   */
  getByAssignee(assigneeId: number): Observable<Issue[]> {
    return this.http
      .get<Issue[] | null>(`${this.baseUrl}/assignee/${assigneeId}`)
      .pipe(orEmptyArray());
  }

  /**
   * Moves an issue to a new status.
   *
   * The Issue microservice exposes only a full PUT, so changing one field still means
   * sending the whole record back. Doing that here means the Assignee screen can call
   * `changeStatus(issue, next)` without knowing anything about the wire format, and no
   * other field can be dropped by accident.
   *
   * @param issue the issue as it was last loaded from the server
   * @param status the status the user picked
   * @returns the updated issue
   */
  changeStatus(issue: Issue, status: IssueStatus): Observable<Issue> {
    return this.update(issue.id, { ...IssueService.toRequest(issue), status });
  }

  /**
   * Converts a stored issue back into the shape the write endpoints expect.
   *
   * Exposed as a static so the Edit Issue form can seed itself from the same conversion
   * the status update uses.
   *
   * @param issue the issue as returned by a GET
   * @returns an equivalent create/update payload
   */
  static toRequest(issue: Issue): IssueRequest {
    return {
      summary: issue.summary,
      description: issue.description,
      projectId: issue.projectId,
      // The backend column is a primitive long, so an unassigned issue arrives as 0.
      // Sending 0 back would make the service look up a user that cannot exist.
      assigneeId: issue.assigneeId > 0 ? issue.assigneeId : null,
      createdBy: issue.createdBy > 0 ? issue.createdBy : null,
      priority: issue.priority,
      status: issue.status,
      type: issue.type,
      sprint: issue.sprint,
      storyPoint: issue.storyPoint,
      tags: issue.tags,
    };
  }
}
