import { Injectable, signal } from '@angular/core';

/** Visual treatment of a toast. */
export type ToastTone = 'success' | 'error' | 'info';

/** A single message shown in the corner of the screen. */
export interface Toast {
  /** Identifies the toast so it can be dismissed and tracked in `@for`. */
  readonly id: number;
  /** Text shown to the user. */
  readonly text: string;
  /** Decides the colour of the toast. */
  readonly tone: ToastTone;
}

/** How long a toast stays on screen, in milliseconds. */
const AUTO_DISMISS_MS = 4500;

/**
 * Collects the short lived messages shown after an action succeeds or fails.
 *
 * Components call `success` or `error` and forget about it; the shell renders whatever
 * is in `toasts`, so no screen needs its own alert markup.
 */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  /** Messages currently on screen. */
  private readonly items = signal<Toast[]>([]);

  /** Read only view for the shell template. */
  readonly toasts = this.items.asReadonly();

  /** Incremented per toast so every id is unique for the lifetime of the page. */
  private nextId = 0;

  /**
   * Reports that an action worked.
   *
   * @param text message to show
   */
  success(text: string): void {
    this.push(text, 'success');
  }

  /**
   * Reports that an action failed.
   *
   * @param text message to show, normally taken from the server response
   */
  error(text: string): void {
    this.push(text, 'error');
  }

  /**
   * Reports something neutral.
   *
   * @param text message to show
   */
  info(text: string): void {
    this.push(text, 'info');
  }

  /**
   * Removes a toast early, when the user clicks its close button.
   *
   * @param id identifier of the toast to remove
   */
  dismiss(id: number): void {
    this.items.update((current) => current.filter((toast) => toast.id !== id));
  }

  /**
   * Adds a toast and schedules its removal.
   *
   * @param text message to show
   * @param tone visual treatment
   */
  private push(text: string, tone: ToastTone): void {
    const id = this.nextId++;
    this.items.update((current) => [...current, { id, text, tone }]);
    setTimeout(() => this.dismiss(id), AUTO_DISMISS_MS);
  }
}
