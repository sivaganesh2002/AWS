import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { Role } from '../models/user.model';
import { AuthService } from '../services/auth.service';

/**
 * Builds a guard that only lets one role through.
 *
 * A factory rather than a plain guard so the route table can read as
 * `canActivate: [authGuard, roleGuard('PROJECT_OWNER')]`, keeping the requirement visible
 * where the route is declared instead of buried in route data.
 *
 * @param allowed the role permitted on this route
 * @returns a guard that redirects anyone else to their own dashboard
 */
export function roleGuard(allowed: Role): CanActivateFn {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);

    if (auth.role() === allowed) {
      return true;
    }

    // Signed in but on the wrong side of the app: send them home rather than to login,
    // which would look like the session had expired.
    return router.parseUrl(auth.isAuthenticated() ? auth.homeRoute() : '/login');
  };
}
