import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { AuthService } from '../services/auth.service';

/**
 * Stamps the signed in user onto every outgoing request.
 *
 * The Week 2 backend does not issue a token, so there is no Authorization header to add.
 * Sending the identity as headers keeps the client honest about who is calling and gives
 * the services something to read the day real authentication is introduced, without any
 * screen having to change.
 */
export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const user = inject(AuthService).currentUser();

  if (user === null) {
    return next(request);
  }

  return next(
    request.clone({
      setHeaders: {
        'X-User-Id': String(user.userId),
        'X-User-Role': user.role,
      },
    }),
  );
};
