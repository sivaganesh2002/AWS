import { Issue } from './issue.model';
import { Project } from './project.model';
import { Role } from './user.model';

/**
 * Aggregated landing payload returned by `GET /api/users/{id}/dashboard`.
 *
 * The backend assembles this by calling the Project Service and the Issue Service, so a
 * dashboard costs the client one round trip instead of three.
 */
export interface DashboardResponse {
  /** Id of the user the dashboard belongs to. */
  readonly userId: number;
  /** Display name, shown as the Project Owner label. */
  readonly name: string;
  /** Decides whether `projects` is populated. */
  readonly role: Role;
  /** Projects owned by this user. Always empty for an ASSIGNEE. */
  readonly projects: Project[];
  /** Issues raised by a PROJECT_OWNER, or assigned to an ASSIGNEE. */
  readonly issues: Issue[];
  /** Count shown in the sidebar. */
  readonly totalProjects: number;
  /** Count shown in the sidebar. */
  readonly totalIssues: number;
  /** How many of the issues above sit in each backend status. */
  readonly issueCountByStatus: Record<string, number>;
}
