/**
 * The single error envelope every microservice returns.
 *
 * Mirrors the backend `ErrorResponse` class, so a failing call can be reported to the
 * user with the server's own wording instead of a generic "something went wrong".
 */
export interface ApiError {
  /** When the failure happened, ISO date-time. */
  readonly timestamp: string;
  /** HTTP status code. */
  readonly status: number;
  /** Reason phrase, e.g. "Not Found". */
  readonly error: string;
  /** Human readable explanation, safe to show to the user. */
  readonly message: string;
  /** Endpoint that produced the failure. */
  readonly path: string;
  /** Field name mapped to the reason it was rejected, only for validation failures. */
  readonly validationErrors?: Record<string, string>;
}
