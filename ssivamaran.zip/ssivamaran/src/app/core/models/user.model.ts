/**
 * The two roles the system recognises.
 *
 * The backend persists these as a TINYINT ordinal but Jackson serialises the enum by
 * name, so the wire format is the string literal shown here.
 */
export type Role = 'PROJECT_OWNER' | 'ASSIGNEE';

/** A registered user, exactly as `GET /api/users/{id}` returns it. */
export interface User {
  /** Generated identifier, starts at 1001 in the backend. */
  readonly userId: number;
  /** Display name, also shown as the assignee name on issue cards. */
  readonly name: string;
  /** Unique login email. */
  readonly email: string;
  /** URL of the profile image. Null when the user never supplied one. */
  readonly profile: string | null;
  /** Determines which dashboard the user lands on. */
  readonly role: Role;
}

/** Payload accepted by `POST /api/users` when signing up. */
export interface SignUpRequest {
  /** Mandatory display name. */
  name: string;
  /** Must be a well formed, not yet registered email. */
  email: string;
  /** Plain text here; the backend stores only a BCrypt hash of it. */
  password: string;
  /** Profile image URL. */
  profile: string;
  /** Chosen on the signup form. */
  role: Role;
}

/** Body returned by `POST /api/users` on success (HTTP 201). */
export interface SignUpResponse {
  /** Human readable confirmation, e.g. "Your account is created successfully". */
  readonly message: string;
  /** Login endpoint the backend suggests navigating to next. */
  readonly loginUrl: string;
  /** The account that was just created, without the password. */
  readonly user: User;
}

/** Credentials submitted by the login form. */
export interface LoginRequest {
  /** Registered email address. */
  email: string;
  /** Plain text password, verified against the stored BCrypt hash. */
  password: string;
}

/** Body returned by `POST /api/users/login` on success. */
export interface LoginResponse {
  /** Human readable confirmation. */
  readonly message: string;
  /** Role aware landing endpoint chosen by the backend. */
  readonly dashboardUrl: string;
  /** The authenticated user, without the password. */
  readonly user: User;
}
