/** A project, exactly as `GET /api/projects/{id}` returns it. */
export interface Project {
  /** Generated identifier, starts at 5001 in the backend. */
  readonly id: number;
  /** Display name shown in the dashboard dropdown. */
  readonly projectName: string;
  /** User id of the owning Project Owner (not the name). */
  readonly projectOwner: number;
  /** ISO `yyyy-MM-dd`, rendered as dd-mm-yyyy in the UI. */
  readonly startDate: string;
  /** ISO `yyyy-MM-dd`, never earlier than `startDate`. */
  readonly endDate: string;
}

/** Payload accepted by `POST /api/projects` and `PUT /api/projects/{id}`. */
export interface ProjectRequest {
  /** Required, max 150 characters on the form, 255 on the server. */
  projectName: string;
  /** User id of the Project Owner. */
  projectOwner: number;
  /** ISO `yyyy-MM-dd`. */
  startDate: string;
  /** ISO `yyyy-MM-dd`, must not precede `startDate`. */
  endDate: string;
}
