/** How urgently an issue needs attention. Mirrors the backend `Priority` enum. */
export type IssuePriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

/** Where an issue sits in its lifecycle. Mirrors the backend `Status` enum. */
export type IssueStatus =
  | 'OPEN'
  | 'IN_PROGRESS'
  | 'IN_REVIEW'
  | 'RESOLVED'
  | 'CLOSED'
  | 'REOPENED';

/** The kind of work an issue represents. Mirrors the backend `IssueType` enum. */
export type IssueType = 'BUG' | 'TASK' | 'STORY' | 'EPIC';

/** An issue, exactly as `GET /api/issues/{id}` returns it. */
export interface Issue {
  /** Generated identifier, starts at 9001 in the backend. */
  readonly id: number;
  /** Short title shown on the card. */
  readonly summary: string;
  /** Longer explanation. Null when the reporter left it blank. */
  readonly description: string | null;
  /** Drives the colour of the priority badge. */
  readonly priority: IssuePriority;
  /** Drives which board column the issue lands in. */
  readonly status: IssueStatus;
  /** Bug / Task / Story / Epic. */
  readonly type: IssueType;
  /** Id of the owning project. */
  readonly projectId: number;
  /** Id of the user working on it. Zero when unassigned, because the column is a primitive long. */
  readonly assigneeId: number;
  /** Id of the user who raised it, normally the Project Owner. */
  readonly createdBy: number;
  /** ISO `yyyy-MM-dd` creation date. */
  readonly createdOn: string | null;
  /** ISO `yyyy-MM-dd` of the last write. */
  readonly lastUpdated: string | null;
  /** Sprint number. Stored as text by the backend, entered as a number in the UI. */
  readonly sprint: string | null;
  /** Effort estimate. The case study restricts this to prime numbers. */
  readonly storyPoint: number | null;
  /** Free form comma separated labels. */
  readonly tags: string | null;
}

/**
 * Payload accepted by `POST /api/issues` and `PUT /api/issues/{id}`.
 *
 * The update endpoint is a full replace rather than a patch, so every field has to be
 * sent back even when only the status changed. `IssueService.changeStatus` does exactly
 * that so callers never have to remember it.
 */
export interface IssueRequest {
  /** Required, 5 to 150 characters on the form. */
  summary: string;
  /** Optional, up to 500 characters on the form. */
  description: string | null;
  /** Required, must reference an existing project. */
  projectId: number;
  /** Required by the case study, optional for the backend. */
  assigneeId: number | null;
  /** The Project Owner raising the issue. */
  createdBy: number | null;
  /** Defaults to MEDIUM on the server when omitted. */
  priority: IssuePriority;
  /** Defaults to OPEN on the server when omitted. */
  status: IssueStatus;
  /** Defaults to TASK on the server when omitted. */
  type: IssueType;
  /** Sprint number as text, e.g. "2". */
  sprint: string | null;
  /** Prime number effort estimate. */
  storyPoint: number | null;
  /** Comma separated labels, max 100 characters. */
  tags: string | null;
}
