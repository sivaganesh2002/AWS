import { IssueStatus } from '../models/issue.model';

/**
 * The four swim lanes the case study asks for on both dashboards.
 *
 * These are a presentation concept and deliberately not the same thing as the backend
 * `Status` enum, which has six values. The map below is the single place where the two
 * vocabularies meet.
 */
export type BoardColumnKey = 'TO_DO' | 'DEVELOPMENT' | 'TESTING' | 'COMPLETED';

/** Everything a board column needs to render itself. */
export interface BoardColumn {
  /** Stable key used for lookups and `@for` tracking. */
  readonly key: BoardColumnKey;
  /** Heading text, e.g. "TO DO". */
  readonly label: string;
  /** Small glyph shown to the left of the heading. */
  readonly icon: string;
  /** CSS custom property value that tints the column rule and the count badge. */
  readonly accent: string;
  /**
   * Backend statuses that belong in this column.
   *
   * The backend carries six statuses where the case study shows four columns, so two of
   * them fold in: a REOPENED issue is work still to be picked up, and CLOSED is just a
   * RESOLVED issue that has been signed off. Nothing is dropped and no issue can appear
   * in two columns, because the six sets below are disjoint and cover the whole enum.
   */
  readonly statuses: readonly IssueStatus[];
  /**
   * The status written back when a user drags or selects this column.
   *
   * A column maps to several statuses on the way in but only one on the way out, so the
   * round trip is predictable.
   */
  readonly canonicalStatus: IssueStatus;
}

/** Ordered left to right exactly as the case study screenshots show them. */
export const BOARD_COLUMNS: readonly BoardColumn[] = [
  {
    key: 'TO_DO',
    label: 'TO DO',
    icon: '☰',
    accent: '#e5484d',
    statuses: ['OPEN', 'REOPENED'],
    canonicalStatus: 'OPEN',
  },
  {
    key: 'DEVELOPMENT',
    label: 'DEVELOPMENT',
    icon: '</>',
    accent: '#f5a623',
    statuses: ['IN_PROGRESS'],
    canonicalStatus: 'IN_PROGRESS',
  },
  {
    key: 'TESTING',
    label: 'TESTING',
    icon: '☰',
    accent: '#3b82f6',
    statuses: ['IN_REVIEW'],
    canonicalStatus: 'IN_REVIEW',
  },
  {
    key: 'COMPLETED',
    label: 'COMPLETED',
    icon: '✓',
    accent: '#22a06b',
    statuses: ['RESOLVED', 'CLOSED'],
    canonicalStatus: 'RESOLVED',
  },
] as const;

/**
 * Reverse index built once at module load: backend status to column key.
 *
 * Building it here keeps `columnOf` an O(1) lookup instead of a scan per issue, which
 * matters because the board re-buckets every issue on each keystroke in the search box.
 */
const COLUMN_BY_STATUS: ReadonlyMap<IssueStatus, BoardColumnKey> = new Map(
  BOARD_COLUMNS.flatMap((column) =>
    column.statuses.map((status): [IssueStatus, BoardColumnKey] => [status, column.key]),
  ),
);

/**
 * Returns the column an issue belongs to.
 *
 * @param status backend status of the issue
 * @returns the matching column key, falling back to TO_DO for a status this build does
 *          not know about, so an unexpected value shows up on the board instead of
 *          silently disappearing.
 */
export function columnOf(status: IssueStatus): BoardColumnKey {
  return COLUMN_BY_STATUS.get(status) ?? 'TO_DO';
}

/**
 * The column an issue sits in, or undefined for an unknown status.
 *
 * @param status backend status of the issue
 * @returns the column definition
 */
function definitionOf(status: IssueStatus): BoardColumn | undefined {
  const key = columnOf(status);
  return BOARD_COLUMNS.find((column) => column.key === key);
}

/**
 * Human readable label for a backend status, e.g. `IN_PROGRESS` becomes "DEVELOPMENT".
 *
 * @param status backend status of the issue
 * @returns the label of the column the status maps to
 */
export function statusLabel(status: IssueStatus): string {
  return definitionOf(status)?.label ?? status;
}

/**
 * The one status that represents a whole column.
 *
 * A status dropdown only offers the four canonical values, so an issue that is CLOSED has
 * to be shown as RESOLVED for the select to match one of its options. Without this the
 * control would render blank and look like the status had been lost.
 *
 * @param status backend status of the issue
 * @returns the canonical status of the column that status belongs to
 */
export function canonicalStatusOf(status: IssueStatus): IssueStatus {
  return definitionOf(status)?.canonicalStatus ?? status;
}
