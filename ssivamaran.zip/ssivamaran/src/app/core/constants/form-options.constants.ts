import { IssuePriority, IssueType } from '../models/issue.model';
import { Role } from '../models/user.model';
import { BOARD_COLUMNS } from './issue-board.constants';

/** A single entry in any of the application's dropdowns. */
export interface SelectOption<T> {
  /** Value bound to the form control. */
  readonly value: T;
  /** Text shown to the user. */
  readonly label: string;
}

/** Roles offered on the login and signup screens. */
export const ROLE_OPTIONS: readonly SelectOption<Role>[] = [
  { value: 'PROJECT_OWNER', label: 'Project Owner' },
  { value: 'ASSIGNEE', label: 'Assignee' },
] as const;

/** Priorities offered when creating or editing an issue. */
export const PRIORITY_OPTIONS: readonly SelectOption<IssuePriority>[] = [
  { value: 'LOW', label: 'Low' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'HIGH', label: 'High' },
  { value: 'CRITICAL', label: 'Critical' },
] as const;

/** Issue types offered when creating or editing an issue. */
export const TYPE_OPTIONS: readonly SelectOption<IssueType>[] = [
  { value: 'BUG', label: 'Bug' },
  { value: 'TASK', label: 'Task' },
  { value: 'STORY', label: 'Story' },
  { value: 'EPIC', label: 'Epic' },
] as const;

/**
 * Statuses offered in the status dropdowns.
 *
 * Derived from the board columns rather than from the raw backend enum so the user is
 * offered the same four words they see on the board, and so adding a column automatically
 * adds its option here.
 */
export const STATUS_OPTIONS = BOARD_COLUMNS.map((column) => ({
  value: column.canonicalStatus,
  label: column.label,
}));
