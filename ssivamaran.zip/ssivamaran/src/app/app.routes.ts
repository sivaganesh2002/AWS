import { Routes } from '@angular/router';

import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

/**
 * Application routes.
 *
 * Every screen is lazy loaded with `loadComponent`, so the login page ships without the
 * dashboards attached to it. Signed in screens sit under the shell, which supplies the
 * sidebar, and are protected by `authGuard` plus the `roleGuard` for the half of the app
 * that belongs to one role.
 */
export const routes: Routes = [
  // ---------------------------------------------------------------------------
  // Public
  // ---------------------------------------------------------------------------
  {
    path: 'login',
    title: 'Login | Issue Tracking System',
    loadComponent: () =>
      import('./features/auth/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'signup',
    title: 'Signup | Issue Tracking System',
    loadComponent: () =>
      import('./features/auth/signup/signup.component').then((m) => m.SignupComponent),
  },

  // ---------------------------------------------------------------------------
  // Project Owner
  // ---------------------------------------------------------------------------
  {
    path: 'owner',
    canActivate: [authGuard, roleGuard('PROJECT_OWNER')],
    loadComponent: () =>
      import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    children: [
      {
        path: 'dashboard',
        title: 'Project Dashboard | Issue Tracking System',
        loadComponent: () =>
          import('./features/project-owner/dashboard/dashboard.component').then(
            (m) => m.OwnerDashboardComponent,
          ),
      },
      {
        path: 'projects/new',
        title: 'Create Project | Issue Tracking System',
        loadComponent: () =>
          import('./features/project-owner/create-project/create-project.component').then(
            (m) => m.CreateProjectComponent,
          ),
      },
      {
        path: 'issues/new',
        title: 'Create Issue | Issue Tracking System',
        loadComponent: () =>
          import('./features/project-owner/create-issue/create-issue.component').then(
            (m) => m.CreateIssueComponent,
          ),
      },
      // The edit route is declared before ':id' so it is not swallowed by it.
      {
        path: 'issues/:id/edit',
        title: 'Edit Issue | Issue Tracking System',
        loadComponent: () =>
          import('./features/project-owner/edit-issue/edit-issue.component').then(
            (m) => m.EditIssueComponent,
          ),
      },
      {
        path: 'issues/:id',
        title: 'Issue Details | Issue Tracking System',
        loadComponent: () =>
          import('./features/project-owner/issue-detail/issue-detail.component').then(
            (m) => m.IssueDetailComponent,
          ),
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
    ],
  },

  // ---------------------------------------------------------------------------
  // Assignee
  // ---------------------------------------------------------------------------
  {
    path: 'assignee',
    canActivate: [authGuard, roleGuard('ASSIGNEE')],
    loadComponent: () =>
      import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    children: [
      {
        path: 'dashboard',
        title: 'My Issues | Issue Tracking System',
        loadComponent: () =>
          import('./features/assignee/dashboard/dashboard.component').then(
            (m) => m.AssigneeDashboardComponent,
          ),
      },
      {
        path: 'issues/:id',
        title: 'Issue Details | Issue Tracking System',
        loadComponent: () =>
          import('./features/assignee/issue-detail/issue-detail.component').then(
            (m) => m.AssigneeIssueDetailComponent,
          ),
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
    ],
  },

  // ---------------------------------------------------------------------------
  // Fallbacks
  // ---------------------------------------------------------------------------
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: '**', redirectTo: 'login' },
];
