import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';

import { Issue } from '../../../core/models/issue.model';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { BoardComponent } from '../../../shared/components/board/board.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { SpinnerComponent } from '../../../shared/components/spinner/spinner.component';
import { buildIssueMatcher } from '../../../shared/utils/issue-search';

/**
 * Assignee dashboard.
 *
 * Simpler than the Project Owner board: an Assignee has no project to choose and nothing
 * to filter, so the screen is the issues assigned to them plus the header search. The
 * issues come from the dashboard payload the store already holds, so opening this screen
 * costs no extra request.
 */
@Component({
  selector: 'app-assignee-dashboard',
  imports: [HeaderComponent, BoardComponent, EmptyStateComponent, SpinnerComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class AssigneeDashboardComponent {
  /** Shared issues and user directory. */
  protected readonly store = inject(DashboardStore);

  /** Navigation to the issue detail screen. */
  private readonly router = inject(Router);

  /** Text typed in the header search box. */
  protected readonly searchTerm = signal('');

  /** The issues left after the search box has been applied. */
  protected readonly filteredIssues = computed<readonly Issue[]>(() => {
    const matches = buildIssueMatcher(this.searchTerm());
    return this.store.issues().filter(matches);
  });

  /**
   * Opens the detail screen for an issue.
   *
   * @param issue the card the user clicked
   */
  protected openIssue(issue: Issue): void {
    void this.router.navigate(['/assignee/issues', issue.id]);
  }
}
