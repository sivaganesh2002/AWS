import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

import {
  STATUS_OPTIONS,
} from '../../../core/constants/form-options.constants';
import { canonicalStatusOf } from '../../../core/constants/issue-board.constants';
import { Issue, IssueStatus } from '../../../core/models/issue.model';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { IssueService } from '../../../core/services/issue.service';
import { NotificationService } from '../../../core/services/notification.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { SpinnerComponent } from '../../../shared/components/spinner/spinner.component';

/**
 * Issue Details screen for an Assignee.
 *
 * Everything is read only except the status: the Assignee picks a new one and Save
 * Updates becomes available. The button stays disabled until the value actually changes,
 * so the screen never sends a PUT that would not alter anything.
 */
@Component({
  selector: 'app-assignee-issue-detail',
  imports: [RouterLink, HeaderComponent, SpinnerComponent],
  templateUrl: './issue-detail.component.html',
  styleUrl: './issue-detail.component.scss',
})
export class AssigneeIssueDetailComponent implements OnInit {
  /** Read and write endpoints. */
  private readonly issueService = inject(IssueService);

  /** Reloaded after a save so the board shows the issue in its new column. */
  private readonly store = inject(DashboardStore);

  /** Success and failure messages. */
  private readonly notifications = inject(NotificationService);

  /** Issue id, bound straight from the `:id` route parameter. */
  readonly id = input.required<string>();

  /** Statuses offered by the dropdown, worded as the board columns. */
  protected readonly statusOptions = STATUS_OPTIONS;

  /** The issue, or null while it loads. */
  protected readonly issue = signal<Issue | null>(null);

  /** The status currently selected in the dropdown. */
  protected readonly selectedStatus = signal<IssueStatus>('OPEN');

  /** True while the issue is being fetched. */
  protected readonly loading = signal(true);

  /** True while a save is in flight. */
  protected readonly saving = signal(false);

  /** Message from the last failure. */
  protected readonly errorMessage = signal<string | null>(null);

  /** Tags split into individual chips. */
  protected readonly tagList = computed<readonly string[]>(() =>
    (this.issue()?.tags ?? '')
      .split(',')
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0),
  );

  /**
   * True once the dropdown differs from what is stored.
   *
   * Compared against the canonical status rather than the raw one, so an issue that is
   * CLOSED and displayed as COMPLETED does not look changed the moment it loads.
   */
  protected readonly hasChanges = computed(() => {
    const current = this.issue();
    return current !== null && this.selectedStatus() !== canonicalStatusOf(current.status);
  });

  /** Fetches the issue named in the route. */
  ngOnInit(): void {
    this.issueService.getById(Number(this.id())).subscribe({
      next: (issue) => {
        this.issue.set(issue);
        this.selectedStatus.set(canonicalStatusOf(issue.status));
        this.loading.set(false);
      },
      error: (failure: unknown) => {
        this.loading.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }

  /**
   * Records the status the user picked.
   *
   * @param value the raw select value
   */
  protected onStatusChange(value: string): void {
    this.selectedStatus.set(value as IssueStatus);
  }

  /** Sends the new status to the Issue Service. */
  protected onSave(): void {
    const current = this.issue();
    if (current === null || !this.hasChanges() || this.saving()) {
      return;
    }

    this.saving.set(true);
    this.errorMessage.set(null);

    this.issueService.changeStatus(current, this.selectedStatus()).subscribe({
      next: (updated) => {
        this.saving.set(false);
        this.issue.set(updated);
        this.selectedStatus.set(canonicalStatusOf(updated.status));
        this.notifications.success(`Issue #${updated.id} updated.`);
        // The board is drawn from the cached dashboard, so refresh it as well.
        this.store.reload();
      },
      error: (failure: unknown) => {
        this.saving.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }
}
