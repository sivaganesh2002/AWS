import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { ROLE_OPTIONS } from '../../../core/constants/form-options.constants';
import { Role } from '../../../core/models/user.model';
import { AuthService } from '../../../core/services/auth.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { NotificationService } from '../../../core/services/notification.service';
import { FieldErrorComponent } from '../../../shared/components/field-error/field-error.component';
import { imageUrlValidator } from '../../../shared/validators/form.validators';

/**
 * Signup screen.
 *
 * Built with reactive forms, as the case study requires, so every rule is declared in one
 * readable block below and the template stays free of validation logic.
 */
@Component({
  selector: 'app-signup',
  imports: [ReactiveFormsModule, RouterLink, FieldErrorComponent],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.scss',
})
export class SignupComponent {
  /** Builds the typed form group. */
  private readonly fb = inject(FormBuilder);

  /** Registration call. */
  private readonly auth = inject(AuthService);

  /** Navigation to the login screen once the account exists. */
  private readonly router = inject(Router);

  /** Confirmation message. */
  private readonly notifications = inject(NotificationService);

  /** Options for the role dropdown. */
  protected readonly roleOptions = ROLE_OPTIONS;

  /** True while the request is in flight. */
  protected readonly submitting = signal(false);

  /** Message from the last failed attempt. */
  protected readonly errorMessage = signal<string | null>(null);

  /**
   * The signup form.
   *
   * The password rule is stricter than the backend minimum of six characters: it also
   * demands a letter and a digit, which is the "proper password format" the case study
   * asks for. Login deliberately does not apply the same rule, because an account created
   * before the policy existed must still be able to sign in.
   */
  protected readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.maxLength(100)]],
    email: ['', [Validators.required, Validators.email]],
    password: [
      '',
      [Validators.required, Validators.minLength(6), Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d).+$/)],
    ],
    profile: ['', [Validators.required, imageUrlValidator()]],
    role: ['' as Role | '', [Validators.required]],
  });

  /** Sends the registration and returns the user to the login screen. */
  protected onSubmit(): void {
    if (this.form.invalid || this.submitting()) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();
    this.submitting.set(true);
    this.errorMessage.set(null);

    this.auth
      .signUp({
        name: value.name.trim(),
        email: value.email.trim(),
        password: value.password,
        profile: value.profile.trim(),
        role: value.role as Role,
      })
      .subscribe({
        next: (response) => {
          this.submitting.set(false);
          this.notifications.success(response.message);
          // The backend does not sign the user in, so send them to login as it suggests.
          void this.router.navigate(['/login']);
        },
        error: (failure: unknown) => {
          this.submitting.set(false);
          this.errorMessage.set(toUserMessage(failure));
        },
      });
  }

  /** Clears every field back to its initial state. */
  protected onReset(): void {
    this.form.reset();
    this.errorMessage.set(null);
  }
}
