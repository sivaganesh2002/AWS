import { Component, inject, signal } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { ROLE_OPTIONS } from '../../../core/constants/form-options.constants';
import { Role } from '../../../core/models/user.model';
import { AuthService } from '../../../core/services/auth.service';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { NotificationService } from '../../../core/services/notification.service';
import { FieldErrorComponent } from '../../../shared/components/field-error/field-error.component';

/** What the login form collects. */
interface LoginFormModel {
  /** Registered email address. */
  email: string;
  /** Plain text password. */
  password: string;
  /** Role the user says they are signing in as. Empty until they pick one. */
  role: Role | '';
}

/**
 * Login screen.
 *
 * Built with template driven forms, as the case study requires. The whole form state
 * lives in `model` and Angular derives the validity from the directives in the template,
 * which is why there is no `FormGroup` anywhere in this class.
 */
@Component({
  selector: 'app-login',
  imports: [FormsModule, RouterLink, FieldErrorComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  /** Session handling. */
  private readonly auth = inject(AuthService);

  /** Cleared on sign in so the new user never sees the previous user data. */
  private readonly store = inject(DashboardStore);

  /** Used to read the `returnUrl` the guard attached. */
  private readonly route = inject(ActivatedRoute);

  /** Navigation after a successful sign in. */
  private readonly router = inject(Router);

  /** Success and failure messages. */
  private readonly notifications = inject(NotificationService);

  /** Options for the role dropdown. */
  protected readonly roleOptions = ROLE_OPTIONS;

  /** The bound form state. */
  protected readonly model: LoginFormModel = { email: '', password: '', role: '' };

  /** True while the login request is in flight, used to disable the button. */
  protected readonly submitting = signal(false);

  /** Message from the last failed attempt, shown above the button. */
  protected readonly errorMessage = signal<string | null>(null);

  /**
   * Validates, authenticates and routes the user to their dashboard.
   *
   * @param form the template driven form, injected from the template
   */
  protected onSubmit(form: NgForm): void {
    if (form.invalid || this.submitting()) {
      // Touch everything so a user who clicks straight through sees what is missing.
      form.control.markAllAsTouched();
      return;
    }

    this.submitting.set(true);
    this.errorMessage.set(null);

    this.auth
      .login({ email: this.model.email, password: this.model.password }, this.model.role as Role)
      .subscribe({
        next: (user) => {
          this.submitting.set(false);
          // Drop anything cached for a previously signed in user.
          this.store.clear();
          this.notifications.success(`Welcome back, ${user.name}.`);

          const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
          void this.router.navigateByUrl(returnUrl ?? this.auth.homeRoute());
        },
        error: (failure: unknown) => {
          this.submitting.set(false);
          // Covers both a rejected password (HTTP 401) and the role mismatch AuthService
          // raises as a plain Error.
          this.errorMessage.set(toUserMessage(failure));
        },
      });
  }
}
