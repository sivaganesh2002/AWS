import { Component, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { NotificationService } from '../../../core/services/notification.service';
import { ProjectService } from '../../../core/services/project.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { FieldErrorComponent } from '../../../shared/components/field-error/field-error.component';
import {
  dateRangeValidator,
  noSpecialCharsValidator,
} from '../../../shared/validators/form.validators';

/**
 * Create Project screen.
 *
 * A reactive form with the field rules the case study lists: a 150 character name limited
 * to letters, digits and `-` `/` `|` `.`, an owner chosen from the users API, and a date
 * range that cannot end before it starts.
 */
@Component({
  selector: 'app-create-project',
  imports: [ReactiveFormsModule, HeaderComponent, FieldErrorComponent],
  templateUrl: './create-project.component.html',
  styleUrl: './create-project.component.scss',
})
export class CreateProjectComponent {
  /** Builds the typed form group. */
  private readonly fb = inject(FormBuilder);

  /** Write endpoint. */
  private readonly projectService = inject(ProjectService);

  /** Reloaded after a successful create so the sidebar count is right. */
  private readonly store = inject(DashboardStore);

  /** Supplies the default owner. */
  private readonly auth = inject(AuthService);

  /** Redirect after a successful create. */
  private readonly router = inject(Router);

  /** Success and failure messages. */
  private readonly notifications = inject(NotificationService);

  /** True while the create request is in flight. */
  protected readonly submitting = signal(false);

  /** Message from the last failed attempt. */
  protected readonly errorMessage = signal<string | null>(null);

  /** Users who can own a project, taken from the directory the store already loaded. */
  protected readonly owners = computed(() =>
    Array.from(this.store.users().values())
      .filter((user) => user.role === 'PROJECT_OWNER')
      .sort((left, right) => left.name.localeCompare(right.name)),
  );

  /**
   * The create form.
   *
   * The date rule sits on the group rather than on either control, because neither date
   * can judge itself; `dateRangeValidator` copies the failure onto the end date so the
   * message appears beside the field the user has to change.
   */
  protected readonly form = this.fb.nonNullable.group(
    {
      projectName: [
        '',
        [Validators.required, Validators.maxLength(150), noSpecialCharsValidator()],
      ],
      projectOwner: [this.auth.currentUser()?.userId ?? 0, [Validators.required, Validators.min(1)]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
    },
    { validators: dateRangeValidator('startDate', 'endDate') },
  );

  /** Validates and creates the project. */
  protected onSubmit(): void {
    if (this.form.invalid || this.submitting()) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();
    this.submitting.set(true);
    this.errorMessage.set(null);

    this.projectService
      .create({
        projectName: value.projectName.trim(),
        // The owner dropdown reports its value as a string, so convert before sending.
        projectOwner: Number(value.projectOwner),
        startDate: value.startDate,
        endDate: value.endDate,
      })
      .subscribe({
        next: (project) => {
          this.submitting.set(false);
          this.notifications.success(`Project "${project.projectName}" created.`);
          // Refresh so the new project shows in the dropdown and the sidebar counter.
          this.store.reload();
          void this.router.navigate(['/owner/dashboard']);
        },
        error: (failure: unknown) => {
          this.submitting.set(false);
          this.errorMessage.set(toUserMessage(failure));
        },
      });
  }

  /** Clears every field back to its initial state. */
  protected onReset(): void {
    this.form.reset({
      projectName: '',
      projectOwner: this.auth.currentUser()?.userId ?? 0,
      startDate: '',
      endDate: '',
    });
    this.errorMessage.set(null);
  }
}
