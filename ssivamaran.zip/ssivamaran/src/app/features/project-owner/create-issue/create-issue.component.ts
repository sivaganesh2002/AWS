import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';

import { IssueRequest } from '../../../core/models/issue.model';
import { AuthService } from '../../../core/services/auth.service';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { IssueService } from '../../../core/services/issue.service';
import { NotificationService } from '../../../core/services/notification.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { IssueFormComponent } from '../issue-form/issue-form.component';

/**
 * Create Issue screen.
 *
 * Owns nothing but the POST: the fields and their rules belong to `IssueFormComponent`,
 * which the Edit screen reuses unchanged.
 */
@Component({
  selector: 'app-create-issue',
  imports: [HeaderComponent, IssueFormComponent, EmptyStateComponent],
  templateUrl: './create-issue.component.html',
  styleUrl: './create-issue.component.scss',
})
export class CreateIssueComponent {
  /** Write endpoint. */
  private readonly issueService = inject(IssueService);

  /** Reloaded after a successful create so the sidebar count is right. */
  private readonly store = inject(DashboardStore);

  /** Supplies the reporter id. */
  private readonly auth = inject(AuthService);

  /** Redirect after a successful create. */
  private readonly router = inject(Router);

  /** Success and failure messages. */
  private readonly notifications = inject(NotificationService);

  /** True while the create request is in flight. */
  protected readonly submitting = signal(false);

  /** Message from the last failed attempt. */
  protected readonly errorMessage = signal<string | null>(null);

  /** Projects offered by the form dropdown. */
  protected readonly projects = this.store.projects;

  /** Users offered by the assignee dropdown, sorted by name. */
  protected readonly users = computed(() =>
    Array.from(this.store.users().values()).sort((left, right) =>
      left.name.localeCompare(right.name),
    ),
  );

  /**
   * Sends the issue the form assembled.
   *
   * @param request the payload emitted by `IssueFormComponent`
   */
  protected onSubmit(request: IssueRequest): void {
    this.submitting.set(true);
    this.errorMessage.set(null);

    // The form does not know who is signed in, so the reporter is stamped on here.
    const payload: IssueRequest = {
      ...request,
      createdBy: this.auth.currentUser()?.userId ?? null,
    };

    this.issueService.create(payload).subscribe({
      next: (issue) => {
        this.submitting.set(false);
        this.notifications.success(`Issue #${issue.id} created.`);
        this.store.reload();
        void this.router.navigate(['/owner/dashboard']);
      },
      error: (failure: unknown) => {
        this.submitting.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }
}
