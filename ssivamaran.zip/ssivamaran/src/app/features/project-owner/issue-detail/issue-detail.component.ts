import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

import { Issue } from '../../../core/models/issue.model';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { IssueService } from '../../../core/services/issue.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { SpinnerComponent } from '../../../shared/components/spinner/spinner.component';
import { DmyDatePipe } from '../../../shared/pipes/dmy-date.pipe';
import { StatusLabelPipe } from '../../../shared/pipes/status-label.pipe';

/**
 * Issue Details screen for a Project Owner.
 *
 * Read only, with an Edit Issue button that hands over to the edit route. Tags arrive as
 * one comma separated string and are split here so each one can be shown as its own chip.
 */
@Component({
  selector: 'app-issue-detail',
  imports: [RouterLink, HeaderComponent, SpinnerComponent, DmyDatePipe, StatusLabelPipe],
  templateUrl: './issue-detail.component.html',
  styleUrl: './issue-detail.component.scss',
})
export class IssueDetailComponent implements OnInit {
  /** Read endpoint. */
  private readonly issueService = inject(IssueService);

  /** Supplies the user directory used to name the assignee. */
  private readonly store = inject(DashboardStore);

  /** Issue id, bound straight from the `:id` route parameter. */
  readonly id = input.required<string>();

  /** The issue, or null while it loads. */
  protected readonly issue = signal<Issue | null>(null);

  /** True while the issue is being fetched. */
  protected readonly loading = signal(true);

  /** Message from a failed load. */
  protected readonly errorMessage = signal<string | null>(null);

  /** Display name of the assignee. */
  protected readonly assigneeName = computed(() => {
    const current = this.issue();
    if (current === null || current.assigneeId === 0) {
      return 'Unassigned';
    }
    return this.store.users().get(current.assigneeId)?.name ?? `User ${current.assigneeId}`;
  });

  /** Tags split into individual chips, empty when the issue carries none. */
  protected readonly tagList = computed<readonly string[]>(() =>
    (this.issue()?.tags ?? '')
      .split(',')
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0),
  );

  /** Fetches the issue named in the route. */
  ngOnInit(): void {
    this.issueService.getById(Number(this.id())).subscribe({
      next: (issue) => {
        this.issue.set(issue);
        this.loading.set(false);
      },
      error: (failure: unknown) => {
        this.loading.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }
}
