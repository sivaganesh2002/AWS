import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { Router } from '@angular/router';

import { Issue, IssueRequest } from '../../../core/models/issue.model';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { IssueService } from '../../../core/services/issue.service';
import { NotificationService } from '../../../core/services/notification.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { SpinnerComponent } from '../../../shared/components/spinner/spinner.component';
import { IssueFormComponent } from '../issue-form/issue-form.component';

/**
 * Edit Issue screen.
 *
 * Loads the issue, hands it to the shared form as its starting values and sends the
 * result back with a PUT.
 */
@Component({
  selector: 'app-edit-issue',
  imports: [HeaderComponent, IssueFormComponent, SpinnerComponent],
  templateUrl: './edit-issue.component.html',
  styleUrl: './edit-issue.component.scss',
})
export class EditIssueComponent implements OnInit {
  /** Read and write endpoints. */
  private readonly issueService = inject(IssueService);

  /** Reloaded after a successful save so the board reflects the change. */
  private readonly store = inject(DashboardStore);

  /** Redirect after a successful save. */
  private readonly router = inject(Router);

  /** Success and failure messages. */
  private readonly notifications = inject(NotificationService);

  /** Issue id, bound straight from the `:id` route parameter. */
  readonly id = input.required<string>();

  /** The issue being edited, or null while it loads. */
  protected readonly issue = signal<Issue | null>(null);

  /** True while the issue is being fetched. */
  protected readonly loading = signal(true);

  /** True while the save request is in flight. */
  protected readonly submitting = signal(false);

  /** Message from the last failure, whether loading or saving. */
  protected readonly errorMessage = signal<string | null>(null);

  /** Projects offered by the form dropdown. */
  protected readonly projects = this.store.projects;

  /** Users offered by the assignee dropdown, sorted by name. */
  protected readonly users = computed(() =>
    Array.from(this.store.users().values()).sort((left, right) =>
      left.name.localeCompare(right.name),
    ),
  );

  /** Fetches the issue named in the route. */
  ngOnInit(): void {
    this.issueService.getById(Number(this.id())).subscribe({
      next: (issue) => {
        this.issue.set(issue);
        this.loading.set(false);
      },
      error: (failure: unknown) => {
        this.loading.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }

  /**
   * Saves the edited issue.
   *
   * @param request the payload emitted by `IssueFormComponent`
   */
  protected onSubmit(request: IssueRequest): void {
    const current = this.issue();
    if (current === null) {
      return;
    }

    this.submitting.set(true);
    this.errorMessage.set(null);

    // The form has no reporter field, so the original reporter is carried across rather
    // than being blanked by the update.
    const payload: IssueRequest = {
      ...request,
      createdBy: current.createdBy > 0 ? current.createdBy : null,
    };

    this.issueService.update(current.id, payload).subscribe({
      next: (updated) => {
        this.submitting.set(false);
        this.notifications.success(`Issue #${updated.id} updated.`);
        this.store.reload();
        void this.router.navigate(['/owner/issues', updated.id]);
      },
      error: (failure: unknown) => {
        this.submitting.set(false);
        this.errorMessage.set(toUserMessage(failure));
      },
    });
  }
}
