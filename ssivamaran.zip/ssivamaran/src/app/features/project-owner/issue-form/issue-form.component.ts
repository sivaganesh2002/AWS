import { Component, effect, inject, input, output } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import {
  PRIORITY_OPTIONS,
  STATUS_OPTIONS,
  TYPE_OPTIONS,
} from '../../../core/constants/form-options.constants';
import {
  Issue,
  IssuePriority,
  IssueRequest,
  IssueStatus,
  IssueType,
} from '../../../core/models/issue.model';
import { Project } from '../../../core/models/project.model';
import { User } from '../../../core/models/user.model';
import { FieldErrorComponent } from '../../../shared/components/field-error/field-error.component';
import {
  noSpecialCharsValidator,
  positiveIntegerValidator,
  primeNumberValidator,
} from '../../../shared/validators/form.validators';

/**
 * The ten field issue form, shared by Create Issue and Edit Issue.
 *
 * Both screens ask for exactly the same fields under exactly the same rules, so the form
 * is defined once here and the two routes differ only in the button label and in what
 * they do with the payload. The component knows nothing about HTTP: it emits an
 * `IssueRequest` and lets its parent decide whether that is a POST or a PUT.
 */
@Component({
  selector: 'app-issue-form',
  imports: [ReactiveFormsModule, FieldErrorComponent],
  templateUrl: './issue-form.component.html',
  styleUrl: './issue-form.component.scss',
})
export class IssueFormComponent {
  /** Builds the typed form group. */
  private readonly fb = inject(FormBuilder);

  /** Projects offered by the project dropdown. */
  readonly projects = input.required<readonly Project[]>();

  /** Users offered by the assignee dropdown. */
  readonly users = input.required<readonly User[]>();

  /** Issue being edited, or null when creating a new one. */
  readonly initial = input<Issue | null>(null);

  /** Text on the submit button, for example "Create" or "Edit". */
  readonly submitLabel = input('Create');

  /** True while the parent has a request in flight, which disables both buttons. */
  readonly pending = input(false);

  /** Emitted with a ready to send payload once the form is valid. */
  readonly submitted = output<IssueRequest>();

  /** Issue types offered by the type dropdown. */
  protected readonly typeOptions = TYPE_OPTIONS;

  /** Priorities offered by the priority dropdown. */
  protected readonly priorityOptions = PRIORITY_OPTIONS;

  /** Statuses offered by the status dropdown, worded as the board columns. */
  protected readonly statusOptions = STATUS_OPTIONS;

  /**
   * The issue form.
   *
   * Summary and description follow the length rules from the case study validation
   * table. Story point accepts prime numbers only, and sprint accepts whole numbers
   * above zero, which is why both have a dedicated validator rather than a plain
   * `Validators.min`.
   */
  protected readonly form = this.fb.nonNullable.group({
    summary: [
      '',
      [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(100),
        noSpecialCharsValidator(),
      ],
    ],
    type: ['TASK' as IssueType, [Validators.required]],
    projectId: [0, [Validators.required, Validators.min(1)]],
    priority: ['MEDIUM' as IssuePriority, [Validators.required]],
    description: [
      '',
      [Validators.required, Validators.minLength(10), Validators.maxLength(500)],
    ],
    assigneeId: [0, [Validators.required, Validators.min(1)]],
    tags: ['', [Validators.maxLength(100)]],
    sprint: ['', [Validators.required, positiveIntegerValidator()]],
    storyPoint: ['', [Validators.required, primeNumberValidator()]],
    status: ['OPEN' as IssueStatus, [Validators.required]],
  });

  constructor() {
    // The edit screen fetches its issue after this component is created, so the form is
    // filled from an effect rather than in the constructor.
    effect(() => {
      const issue = this.initial();
      if (issue !== null) {
        this.patchFrom(issue);
      }
    });
  }

  /** Validates and hands a payload to the parent. */
  protected onSubmit(): void {
    if (this.form.invalid || this.pending()) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();

    // A native <select> always reports its value as a string, so the two id controls hold
    // "5001" rather than 5001 at runtime whatever their declared type says. Converting
    // here means the backend receives real JSON numbers.
    this.submitted.emit({
      summary: value.summary.trim(),
      description: value.description.trim(),
      projectId: Number(value.projectId),
      assigneeId: Number(value.assigneeId),
      // Set by the parent, which knows whether this is a create or an edit.
      createdBy: null,
      priority: value.priority,
      status: value.status,
      type: value.type,
      sprint: value.sprint.trim(),
      storyPoint: Number(value.storyPoint),
      tags: value.tags.trim() === '' ? null : value.tags.trim(),
    });
  }

  /** Returns the form to the issue it started from, or to blank when creating. */
  protected onReset(): void {
    const issue = this.initial();
    if (issue === null) {
      this.form.reset();
      return;
    }
    this.patchFrom(issue);
  }

  /**
   * Copies a stored issue into the form controls.
   *
   * @param issue the issue being edited
   */
  private patchFrom(issue: Issue): void {
    this.form.setValue({
      summary: issue.summary,
      type: issue.type,
      projectId: issue.projectId,
      priority: issue.priority,
      description: issue.description ?? '',
      assigneeId: issue.assigneeId,
      tags: issue.tags ?? '',
      sprint: issue.sprint ?? '',
      storyPoint: issue.storyPoint === null ? '' : String(issue.storyPoint),
      status: issue.status,
    });
  }
}
