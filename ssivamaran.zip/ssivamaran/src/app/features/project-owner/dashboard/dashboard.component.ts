import { Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { PRIORITY_OPTIONS } from '../../../core/constants/form-options.constants';
import { Issue, IssuePriority } from '../../../core/models/issue.model';
import { User } from '../../../core/models/user.model';
import { DashboardStore } from '../../../core/services/dashboard-store.service';
import { toUserMessage } from '../../../core/services/http-helpers';
import { IssueService } from '../../../core/services/issue.service';
import { NotificationService } from '../../../core/services/notification.service';
import { HeaderComponent } from '../../../layout/header/header.component';
import { BoardComponent } from '../../../shared/components/board/board.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { SpinnerComponent } from '../../../shared/components/spinner/spinner.component';
import { DmyDatePipe } from '../../../shared/pipes/dmy-date.pipe';
import { buildIssueMatcher } from '../../../shared/utils/issue-search';

/** Sentinel used by the two filter dropdowns to mean "do not filter". */
const ALL = 'ALL';

/**
 * Project Owner dashboard.
 *
 * Shows one project at a time: its details across the top, its issues on the four column
 * board below. Searching and both filters run entirely in the browser over the issues
 * already fetched, which is what the case study asks for and what keeps the board
 * responsive on every keystroke.
 */
@Component({
  selector: 'app-owner-dashboard',
  imports: [
    FormsModule,
    HeaderComponent,
    BoardComponent,
    EmptyStateComponent,
    SpinnerComponent,
    DmyDatePipe,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class OwnerDashboardComponent {
  /** Shared projects, counts and user directory. */
  protected readonly store = inject(DashboardStore);

  /** Used to fetch the issues of the selected project. */
  private readonly issueService = inject(IssueService);

  /** Navigation to the issue detail screen. */
  private readonly router = inject(Router);

  /** Reports a failed issue load. */
  private readonly notifications = inject(NotificationService);

  /** Priorities offered by the priority filter. */
  protected readonly priorityOptions = PRIORITY_OPTIONS;

  /** Sentinel exposed to the template so both dropdowns can bind to it. */
  protected readonly all = ALL;

  /** Project currently shown, or null before the first project loads. */
  protected readonly selectedProjectId = signal<number | null>(null);

  /** Issues of the selected project, straight from the Issue Service. */
  protected readonly issues = signal<readonly Issue[]>([]);

  /** True while the issues of a project are being fetched. */
  protected readonly loadingIssues = signal(false);

  /** Text typed in the header search box. */
  protected readonly searchTerm = signal('');

  /** Selected assignee id, or ALL. */
  protected readonly assigneeFilter = signal<number | typeof ALL>(ALL);

  /** Selected priority, or ALL. */
  protected readonly priorityFilter = signal<IssuePriority | typeof ALL>(ALL);

  /** The project the dropdown is pointing at. */
  protected readonly selectedProject = computed(
    () => this.store.projects().find((project) => project.id === this.selectedProjectId()) ?? null,
  );

  /** Display name of the owner, resolved through the user directory. */
  protected readonly ownerName = computed(() => {
    const project = this.selectedProject();
    if (project === null) {
      return '-';
    }
    return this.store.users().get(project.projectOwner)?.name ?? `User ${project.projectOwner}`;
  });

  /**
   * The team members who appear on this board.
   *
   * Built from the issues rather than from the whole user list, so the dropdown offers
   * the people actually working on the project instead of everybody who ever signed up.
   */
  protected readonly assigneeOptions = computed<readonly User[]>(() => {
    const directory = this.store.users();
    const seen = new Set<number>();
    const people: User[] = [];

    for (const issue of this.issues()) {
      if (issue.assigneeId > 0 && !seen.has(issue.assigneeId)) {
        seen.add(issue.assigneeId);
        const user = directory.get(issue.assigneeId);
        if (user) {
          people.push(user);
        }
      }
    }

    return people.sort((left, right) => left.name.localeCompare(right.name));
  });

  /** The issues left after the search box and both filters have been applied. */
  protected readonly filteredIssues = computed<readonly Issue[]>(() => {
    const matchesSearch = buildIssueMatcher(this.searchTerm());
    const assignee = this.assigneeFilter();
    const priority = this.priorityFilter();

    return this.issues().filter(
      (issue) =>
        matchesSearch(issue) &&
        (assignee === ALL || issue.assigneeId === assignee) &&
        (priority === ALL || issue.priority === priority),
    );
  });

  constructor() {
    // The project list arrives asynchronously from the store, so the default selection
    // has to wait for it. The case study asks for the first project from the API
    // response to be chosen by default.
    effect(() => {
      const projects = this.store.projects();
      if (projects.length > 0 && this.selectedProjectId() === null) {
        this.selectProject(projects[0].id);
      }
    });
  }

  /**
   * Switches the board to another project and loads its issues.
   *
   * @param projectId the project the user picked
   */
  protected selectProject(projectId: number): void {
    this.selectedProjectId.set(projectId);
    // Filters describe the previous project, so reset them rather than carry them over.
    this.assigneeFilter.set(ALL);
    this.priorityFilter.set(ALL);
    this.loadIssues(projectId);
  }

  /**
   * Reads the project id off the dropdown, which always hands back a string.
   *
   * @param value the raw select value
   */
  protected onProjectChange(value: string): void {
    this.selectProject(Number(value));
  }

  /**
   * Reads the assignee filter, mapping the sentinel back to ALL.
   *
   * @param value the raw select value
   */
  protected onAssigneeChange(value: string): void {
    this.assigneeFilter.set(value === ALL ? ALL : Number(value));
  }

  /**
   * Reads the priority filter.
   *
   * @param value the raw select value
   */
  protected onPriorityChange(value: string): void {
    this.priorityFilter.set(value === ALL ? ALL : (value as IssuePriority));
  }

  /**
   * Opens the detail screen for an issue.
   *
   * @param issue the card the user clicked
   */
  protected openIssue(issue: Issue): void {
    void this.router.navigate(['/owner/issues', issue.id]);
  }

  /**
   * Fetches the issues of one project.
   *
   * @param projectId the project whose board is being drawn
   */
  private loadIssues(projectId: number): void {
    this.loadingIssues.set(true);

    this.issueService.getByProject(projectId).subscribe({
      next: (issues) => {
        this.issues.set(issues);
        this.loadingIssues.set(false);
      },
      error: (failure: unknown) => {
        this.issues.set([]);
        this.loadingIssues.set(false);
        this.notifications.error(toUserMessage(failure));
      },
    });
  }
}
