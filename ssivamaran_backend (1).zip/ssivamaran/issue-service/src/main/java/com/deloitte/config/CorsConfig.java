package com.deloitte.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Allows the aggregated Swagger UI (served by the API Gateway on a different port) and any
 * browser based client to call this service's endpoints without being blocked by the browser's
 * same origin policy. Without this, "Try it out" in Swagger UI fails with a CORS / "Failed to fetch"
 * error because the UI origin (gateway) differs from the service origin.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
				.allowedOriginPatterns("*")
				.allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
				.allowedHeaders("*")
				.allowCredentials(true);
	}
}
